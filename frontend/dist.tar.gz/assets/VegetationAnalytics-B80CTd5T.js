import { importShared } from './__federation_fn_import-Bs2X4leW.js';
import { j as jsxRuntimeExports } from './jsx-runtime-CsM3lTE3.js';
import { u as useVegetationContext } from './vegetationContext-DfeO2cmt.js';
import { c as createLucideIcon, u as useVegetationApi } from './createLucideIcon-e3PcgQAe.js';
import { T as TrendingUp, a as TrendingDown } from './trending-up-w_NvEqsU.js';
import { A as Activity, C as CircleCheckBig } from './circle-check-big-FchppnUZ.js';
import { C as Calendar } from './calendar-BM24y3pm.js';
import { L as Layers } from './layers-DK5sOaWK.js';

/**
 * @license lucide-react v0.424.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const ArrowLeft = createLucideIcon("ArrowLeft", [
  ["path", { d: "m12 19-7-7 7-7", key: "1l729n" }],
  ["path", { d: "M19 12H5", key: "x3x0zl" }]
]);

/**
 * @license lucide-react v0.424.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const ArrowRight = createLucideIcon("ArrowRight", [
  ["path", { d: "M5 12h14", key: "1ays0h" }],
  ["path", { d: "m12 5 7 7-7 7", key: "xquz4c" }]
]);

/**
 * @license lucide-react v0.424.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const Minus = createLucideIcon("Minus", [["path", { d: "M5 12h14", key: "1ays0h" }]]);

const TimeseriesChart = ({
  series,
  indexType,
  className = "",
  height = 300
}) => {
  if (series.length === 0 || series.every((s) => s.data.length === 0)) {
    return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `bg-gray-50 rounded-lg p-8 text-center text-gray-500 ${className}`, children: /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: "No data available for timeseries" }) });
  }
  const allDates = /* @__PURE__ */ new Set();
  series.forEach((s) => s.data.forEach((d) => allDates.add(d.date)));
  const sortedDates = Array.from(allDates).sort();
  const allValues = series.flatMap((s) => s.data.map((d) => d.value));
  const minValue = Math.min(...allValues);
  const maxValue = Math.max(...allValues);
  const valueRange = maxValue - minValue || 1;
  const chartPadding = { top: 20, right: 20, bottom: 40, left: 50 };
  const chartWidth = 600;
  const chartHeight = height;
  const plotWidth = chartWidth - chartPadding.left - chartPadding.right;
  const plotHeight = chartHeight - chartPadding.top - chartPadding.bottom;
  const valueToY = (value) => {
    const normalized = (value - minValue) / valueRange;
    return chartPadding.top + plotHeight - normalized * plotHeight;
  };
  const dateToX = (_date, index) => {
    return chartPadding.left + index / (sortedDates.length - 1 || 1) * plotWidth;
  };
  const calculateTrend = (data) => {
    if (data.length < 2) return null;
    const first = data[0].value;
    const last = data[data.length - 1].value;
    const change = last - first;
    const percentChange = change / first * 100;
    return { change, percentChange };
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `bg-white rounded-lg border border-gray-200 p-4 ${className}`, children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("h3", { className: "text-lg font-semibold text-gray-900", children: [
        indexType,
        " Timeseries"
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-gray-500", children: "Evolution over time" })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex flex-wrap gap-4 mb-4", children: series.map((s, idx) => {
      const trend = calculateTrend(s.data);
      return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "div",
          {
            className: "w-4 h-0.5",
            style: {
              backgroundColor: s.color,
              borderStyle: s.dashed ? "dashed" : "solid"
            }
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-sm text-gray-700", children: s.label }),
        trend && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1", children: [
          trend.change > 0 ? /* @__PURE__ */ jsxRuntimeExports.jsx(TrendingUp, { className: "w-4 h-4 text-green-600" }) : trend.change < 0 ? /* @__PURE__ */ jsxRuntimeExports.jsx(TrendingDown, { className: "w-4 h-4 text-red-600" }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Minus, { className: "w-4 h-4 text-gray-400" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs(
            "span",
            {
              className: `text-xs font-semibold ${trend.change > 0 ? "text-green-600" : trend.change < 0 ? "text-red-600" : "text-gray-400"}`,
              children: [
                trend.change > 0 ? "+" : "",
                trend.percentChange.toFixed(1),
                "%"
              ]
            }
          )
        ] })
      ] }, idx);
    }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "overflow-x-auto", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("svg", { width: chartWidth, height: chartHeight, className: "border-t border-l border-gray-200", children: [
      [0, 0.25, 0.5, 0.75, 1].map((ratio) => {
        const y = chartPadding.top + plotHeight - ratio * plotHeight;
        const value = minValue + ratio * valueRange;
        return /* @__PURE__ */ jsxRuntimeExports.jsxs("g", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "line",
            {
              x1: chartPadding.left,
              y1: y,
              x2: chartPadding.left + plotWidth,
              y2: y,
              stroke: "#e5e7eb",
              strokeWidth: 1,
              strokeDasharray: "2,2"
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "text",
            {
              x: chartPadding.left - 10,
              y: y + 4,
              textAnchor: "end",
              className: "text-xs fill-gray-500",
              children: value.toFixed(2)
            }
          )
        ] }, ratio);
      }),
      series.map((s, seriesIdx) => {
        const points = sortedDates.map((date, dateIdx) => {
          const dataPoint = s.data.find((d) => d.date === date);
          if (!dataPoint) return null;
          return {
            x: dateToX(date, dateIdx),
            y: valueToY(dataPoint.value)
          };
        }).filter((p) => p !== null);
        if (points.length < 2) return null;
        const pathData = points.map((p, idx) => `${idx === 0 ? "M" : "L"} ${p.x} ${p.y}`).join(" ");
        return /* @__PURE__ */ jsxRuntimeExports.jsxs("g", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "path",
            {
              d: pathData,
              fill: "none",
              stroke: s.color,
              strokeWidth: 2,
              strokeDasharray: s.dashed ? "5,5" : "0",
              opacity: 0.8
            }
          ),
          points.map((p, pointIdx) => /* @__PURE__ */ jsxRuntimeExports.jsx(
            "circle",
            {
              cx: p.x,
              cy: p.y,
              r: 4,
              fill: s.color,
              className: "hover:r-6 transition-all"
            },
            pointIdx
          ))
        ] }, seriesIdx);
      }),
      sortedDates.map((date, idx) => {
        if (idx % Math.ceil(sortedDates.length / 6) !== 0 && idx !== sortedDates.length - 1)
          return null;
        const x = dateToX(date, idx);
        const dateObj = new Date(date);
        return /* @__PURE__ */ jsxRuntimeExports.jsx(
          "text",
          {
            x,
            y: chartHeight - chartPadding.bottom + 20,
            textAnchor: "middle",
            className: "text-xs fill-gray-500",
            children: dateObj.toLocaleDateString("es-ES", { month: "short", day: "numeric" })
          },
          idx
        );
      })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-4 grid grid-cols-2 gap-4 text-sm", children: series.map((s, idx) => {
      if (s.data.length === 0) return null;
      const values = s.data.map((d) => d.value);
      const mean = values.reduce((a, b) => a + b, 0) / values.length;
      const min = Math.min(...values);
      const max = Math.max(...values);
      return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-gray-50 p-3 rounded", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "font-semibold text-gray-900 mb-1", children: s.label }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-xs text-gray-600 space-y-1", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            "Media: ",
            mean.toFixed(3)
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            "Rango: ",
            min.toFixed(3),
            " - ",
            max.toFixed(3)
          ] })
        ] })
      ] }, idx);
    }) })
  ] });
};

const {useState: useState$2,useEffect: useEffect$1,useCallback,useMemo} = await importShared('react');

function useAuth() {
  const [auth, setAuth] = useState$2({
    isAuthenticated: false,
    roles: []
  });
  useEffect$1(() => {
    const checkAuth = () => {
      const hostAuth = window.__nekazariAuthContext;
      if (hostAuth) {
        const newToken = typeof hostAuth.getToken === "function" ? hostAuth.getToken() : hostAuth.token;
        if (newToken !== auth.token) {
          setAuth({
            isAuthenticated: !!newToken,
            token: newToken,
            tenantId: typeof hostAuth.getTenantId === "function" ? hostAuth.getTenantId() : hostAuth.tenantId,
            user: hostAuth.user,
            roles: hostAuth.roles || [],
            login: hostAuth.login,
            logout: hostAuth.logout
          });
        }
      }
    };
    checkAuth();
    const interval = setInterval(checkAuth, 1e3);
    return () => clearInterval(interval);
  }, [auth.token]);
  const getToken = useCallback(() => auth.token, [auth.token]);
  const getTenantId = useCallback(() => auth.tenantId, [auth.tenantId]);
  const hasRole = useCallback((role) => auth.roles?.includes(role) ?? false, [auth.roles]);
  return useMemo(() => ({
    ...auth,
    getToken,
    getTenantId,
    hasRole
  }), [auth, getToken, getTenantId, hasRole]);
}

const {useState: useState$1} = await importShared('react');

const {Button: Button$1,Modal} = await importShared('@nekazari/ui-kit');
const SetupWizard = ({
  open,
  onClose,
  entityId,
  entityName = "Parcela seleccionada",
  geometry,
  onComplete
}) => {
  const api = useVegetationApi();
  const [step, setStep] = useState$1(1);
  const [loading, setLoading] = useState$1(false);
  const [error, setError] = useState$1(null);
  const [startDate, setStartDate] = useState$1(() => {
    const date = /* @__PURE__ */ new Date();
    date.setFullYear(date.getFullYear() - 1);
    return date.toISOString().split("T")[0];
  });
  const [selectedIndices, setSelectedIndices] = useState$1(["NDVI", "EVI"]);
  const [frequency, setFrequency] = useState$1("weekly");
  const availableIndices = [
    { id: "NDVI", name: "NDVI (Vigor General)", desc: "Índice de Diferencia Normalizada de Vegetación. Estándar para salud vegetal." },
    { id: "EVI", name: "EVI (Alta Densidad)", desc: "Índice de Vegetación Mejorado. Mejor para zonas con mucha biomasa." },
    { id: "GNDVI", name: "GNDVI (Clorofila)", desc: "Sensible al contenido de clorofila y estrés hídrico." },
    { id: "SAVI", name: "SAVI (Suelo)", desc: "Ajustado al suelo. Recomendado para etapas tempranas de cultivo." },
    { id: "NDRE", name: "NDRE (Borde Rojo)", desc: "Usa banda Red Edge. Útil para cultivos permanentes y etapas finales." }
  ];
  const handleToggleIndex = (id) => {
    setSelectedIndices(
      (prev) => prev.includes(id) ? prev.filter((i) => i !== id) : [...prev, id]
    );
  };
  const handleSubmit = async () => {
    setLoading(true);
    setError(null);
    try {
      await api.createSubscription({
        entity_id: entityId,
        geometry,
        // Important: Pass geometry for scene search
        start_date: startDate,
        index_types: selectedIndices,
        frequency,
        is_active: true
      });
      onComplete();
      onClose();
    } catch (err) {
      console.error(err);
      setError(err.message || "Error al guardar la configuración");
    } finally {
      setLoading(false);
    }
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsx(
    Modal,
    {
      isOpen: open,
      onClose,
      title: `Configurar Monitoreo: ${entityName}`,
      size: "lg",
      children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-6", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between mb-8 px-8", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `flex flex-col items-center ${step >= 1 ? "text-green-600" : "text-slate-400"}`, children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `w-8 h-8 rounded-full flex items-center justify-center mb-2 ${step >= 1 ? "bg-green-100 font-bold" : "bg-slate-100"}`, children: "1" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs font-medium", children: "Parcela" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `h-1 flex-1 mx-4 ${step >= 2 ? "bg-green-500" : "bg-slate-200"}` }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `flex flex-col items-center ${step >= 2 ? "text-green-600" : "text-slate-400"}`, children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `w-8 h-8 rounded-full flex items-center justify-center mb-2 ${step >= 2 ? "bg-green-100 font-bold" : "bg-slate-100"}`, children: "2" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs font-medium", children: "Configuración" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `h-1 flex-1 mx-4 ${step >= 3 ? "bg-green-500" : "bg-slate-200"}` }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `flex flex-col items-center ${step >= 3 ? "text-green-600" : "text-slate-400"}`, children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `w-8 h-8 rounded-full flex items-center justify-center mb-2 ${step >= 3 ? "bg-green-100 font-bold" : "bg-slate-100"}`, children: "3" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs font-medium", children: "Confirmar" })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "min-h-[300px]", children: [
          step === 1 && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-center space-y-6", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto text-green-600", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Activity, { size: 32 }) }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-xl font-bold text-slate-800", children: "Activar Monitoreo Automático" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-slate-500 mt-2 max-w-md mx-auto", children: "Vamos a configurar la descarga automática de imágenes satelitales y el cálculo semanal de índices de vegetación para esta parcela." })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-slate-50 p-4 rounded-lg inline-block text-left border border-slate-200", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm font-semibold text-slate-700", children: "Parcela seleccionada:" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-slate-600", children: entityName }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-xs text-slate-400 mt-1", children: [
                "ID: ",
                entityId
              ] })
            ] })
          ] }),
          step === 2 && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-6", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "block text-sm font-medium text-slate-700 mb-2", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Calendar, { className: "inline w-4 h-4 mr-1" }),
                " Fecha de inicio de datos históricos"
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "input",
                {
                  type: "date",
                  value: startDate,
                  onChange: (e) => setStartDate(e.target.value),
                  className: "w-full border-slate-300 rounded-md shadow-sm focus:border-green-500 focus:ring-green-500"
                }
              ),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 mt-1", children: "Descargaremos imágenes disponibles desde esta fecha." })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "block text-sm font-medium text-slate-700 mb-2", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(Layers, { className: "inline w-4 h-4 mr-1" }),
                " Índices a calcular automáticamente"
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-2 max-h-48 overflow-y-auto border border-slate-200 rounded-md p-2", children: availableIndices.map((idx) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start p-2 hover:bg-slate-50 rounded cursor-pointer", onClick: () => handleToggleIndex(idx.id), children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "input",
                  {
                    type: "checkbox",
                    checked: selectedIndices.includes(idx.id),
                    onChange: () => {
                    },
                    className: "mt-1 h-4 w-4 text-green-600 focus:ring-green-500 border-gray-300 rounded"
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "ml-3", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "block text-sm font-medium text-slate-700", children: idx.name }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "block text-xs text-slate-500", children: idx.desc })
                ] })
              ] }, idx.id)) })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-sm font-medium text-slate-700 mb-2", children: "Frecuencia de actualización" }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex gap-4", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "flex items-center", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "input",
                    {
                      type: "radio",
                      name: "frequency",
                      value: "weekly",
                      checked: frequency === "weekly",
                      onChange: () => setFrequency("weekly"),
                      className: "focus:ring-green-500 h-4 w-4 text-green-600 border-gray-300"
                    }
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "ml-2 text-sm text-slate-700", children: "Semanal (Recomendado)" })
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "flex items-center", children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "input",
                    {
                      type: "radio",
                      name: "frequency",
                      value: "daily",
                      checked: frequency === "daily",
                      onChange: () => setFrequency("daily"),
                      className: "focus:ring-green-500 h-4 w-4 text-green-600 border-gray-300"
                    }
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "ml-2 text-sm text-slate-700", children: "Diaria (Consume más créditos)" })
                ] })
              ] })
            ] })
          ] }),
          step === 3 && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-6", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-green-50 border border-green-200 rounded-lg p-4", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("h4", { className: "font-semibold text-green-800 flex items-center", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(CircleCheckBig, { className: "w-5 h-5 mr-2" }),
                " Resumen de Configuración"
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("ul", { className: "mt-2 space-y-1 text-sm text-green-700", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("li", { children: [
                  "• ",
                  /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: "Parcela:" }),
                  " ",
                  entityName
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("li", { children: [
                  "• ",
                  /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: "Inicio Histórico:" }),
                  " ",
                  startDate
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("li", { children: [
                  "• ",
                  /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: "Índices:" }),
                  " ",
                  selectedIndices.join(", ")
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("li", { children: [
                  "• ",
                  /* @__PURE__ */ jsxRuntimeExports.jsx("strong", { children: "Frecuencia:" }),
                  " ",
                  frequency === "weekly" ? "Semanal" : "Diaria"
                ] })
              ] })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-sm text-slate-600", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: 'Al hacer clic en "Activar", el sistema comenzará a:' }),
              /* @__PURE__ */ jsxRuntimeExports.jsxs("ol", { className: "list-decimal list-inside mt-2 space-y-1 ml-2", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: "Buscar imágenes satelitales históricas disponibles." }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: "Calcular los índices seleccionados." }),
                /* @__PURE__ */ jsxRuntimeExports.jsx("li", { children: "Programar las próximas actualizaciones automáticas." })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "mt-4 text-xs text-slate-500 italic", children: "Nota: El proceso inicial puede tomar unos minutos dependiendo del rango de fechas seleccionado. Recibirás una notificación cuando los datos estén listos." })
            ] }),
            error && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-red-50 border border-red-200 text-red-700 p-3 rounded text-sm", children: [
              "Error: ",
              error
            ] })
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mt-8 flex justify-between border-t border-slate-100 pt-4", children: [
          step > 1 ? /* @__PURE__ */ jsxRuntimeExports.jsxs(Button$1, { variant: "ghost", onClick: () => setStep(step - 1), disabled: loading, children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowLeft, { className: "w-4 h-4 mr-2" }),
            " Atrás"
          ] }) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", {}),
          step < 3 ? /* @__PURE__ */ jsxRuntimeExports.jsxs(Button$1, { variant: "primary", onClick: () => setStep(step + 1), children: [
            "Continuar ",
            /* @__PURE__ */ jsxRuntimeExports.jsx(ArrowRight, { className: "w-4 h-4 ml-2" })
          ] }) : /* @__PURE__ */ jsxRuntimeExports.jsx(Button$1, { variant: "primary", onClick: handleSubmit, disabled: loading, className: "bg-green-600 hover:bg-green-700", children: loading ? "Activando..." : "Activar Monitoreo" })
        ] })
      ] })
    }
  );
};

const React = await importShared('react');
const {useState,useEffect} = React;

const {Card} = await importShared('@nekazari/ui-kit');
const {Button} = await importShared('@nekazari/ui-kit');

const VegetationAnalytics = () => {
  const { selectedIndex, selectedEntityId, setSelectedEntityId, selectedGeometry } = useVegetationContext();
  const { isAuthenticated } = useAuth();
  const api = useVegetationApi();
  const [recentJobs, setRecentJobs] = useState([]);
  const [loadingJobs, setLoadingJobs] = useState(false);
  const [subscription, setSubscription] = useState(null);
  const [checkingSub, setCheckingSub] = useState(false);
  const [showWizard, setShowWizard] = useState(false);
  useEffect(() => {
    if (selectedEntityId && isAuthenticated) {
      setCheckingSub(true);
      api.getSubscriptionForEntity(selectedEntityId).then(setSubscription).catch(() => setSubscription(null)).finally(() => setCheckingSub(false));
      setLoadingJobs(true);
      api.listJobs("completed", 20, 0).then((response) => {
        setRecentJobs(response.jobs.filter((j) => j.entity_id === selectedEntityId));
      }).catch(console.error).finally(() => setLoadingJobs(false));
    } else {
      setSubscription(null);
      if (!selectedEntityId && isAuthenticated) {
        setLoadingJobs(true);
        api.listJobs("completed", 20, 0).then((response) => setRecentJobs(response.jobs)).catch(console.error).finally(() => setLoadingJobs(false));
      }
    }
  }, [selectedEntityId, isAuthenticated]);
  const uniqueEntities = React.useMemo(() => {
    if (selectedEntityId) return [];
    const map = /* @__PURE__ */ new Map();
    if (recentJobs && Array.isArray(recentJobs)) {
      recentJobs.forEach((job) => {
        if (job.entity_id && !map.has(job.entity_id)) {
          map.set(job.entity_id, job);
        }
      });
    }
    return Array.from(map.values());
  }, [recentJobs, selectedEntityId]);
  if (!isAuthenticated) {
    return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center justify-center h-64", children: /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-gray-500", children: "Please log in to view analytics." }) });
  }
  if (!selectedEntityId) {
    return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-6 max-w-4xl mx-auto py-8", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center justify-center h-32 bg-slate-50 rounded-xl border border-dashed border-slate-300", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-center", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-slate-500 font-medium", children: "No parcel selected." }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-400", children: "Select a recently analyzed parcel below or use the map." })
      ] }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-lg font-semibold text-slate-800 mb-4", children: "Recently Analyzed Parcels" }),
        loadingJobs ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-center py-4 text-slate-500", children: "Loading history..." }) : uniqueEntities.length > 0 ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-4", children: uniqueEntities.map((job) => /* @__PURE__ */ jsxRuntimeExports.jsx(
          "div",
          {
            className: "cursor-pointer hover:opacity-80 transition-opacity",
            onClick: () => setSelectedEntityId(job.entity_id || null),
            children: /* @__PURE__ */ jsxRuntimeExports.jsx(Card, { padding: "md", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex justify-between items-start", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "font-medium text-slate-900", children: [
                  job.entity_type,
                  " ",
                  job.entity_id?.substring(0, 8),
                  "..."
                ] }),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-xs text-slate-500", children: [
                  "Last Analysis: ",
                  new Date(job.created_at).toLocaleDateString()
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "bg-green-100 text-green-800 text-xs px-2 py-1 rounded-full", children: job.job_type })
            ] }) })
          },
          job.entity_id
        )) }) : /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-slate-500 text-sm", children: "No analysis history found." })
      ] })
    ] });
  }
  if (!checkingSub && !subscription && selectedEntityId) {
    return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-6 max-w-4xl mx-auto py-8", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex justify-between items-center", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-2xl font-bold text-slate-800", children: "Parcel Analysis" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            onClick: () => setSelectedEntityId(null),
            className: "text-sm text-slate-500 hover:text-slate-700 underline",
            children: "Change Parcel"
          }
        )
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white rounded-xl shadow-sm border border-slate-200 p-8 text-center space-y-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center mx-auto text-slate-400 mb-4", children: /* @__PURE__ */ jsxRuntimeExports.jsx("svg", { className: "w-8 h-8", fill: "none", viewBox: "0 0 24 24", stroke: "currentColor", children: /* @__PURE__ */ jsxRuntimeExports.jsx("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: 2, d: "M12 6v6m0 0v6m0-6h6m-6 0H6" }) }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-xl font-semibold text-slate-900", children: "Monitoreo Inactivo" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-slate-500 max-w-md mx-auto", children: "Esta parcela no tiene el monitoreo automático activado. Configúralo para descargar imágenes históricas y recibir actualizaciones semanales." }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "pt-4", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Button, { variant: "primary", onClick: () => setShowWizard(true), children: "Configurar Monitoreo" }) })
      ] }),
      recentJobs.length > 0 && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "opacity-70", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("h4", { className: "text-md font-semibold text-slate-700 mb-2", children: "Historial Manual" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-2", children: recentJobs.map((job) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-slate-50 p-3 rounded flex justify-between text-sm", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: new Date(job.created_at).toLocaleDateString() }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "capitalize", children: job.status })
        ] }, job.id)) })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        SetupWizard,
        {
          open: showWizard,
          onClose: () => setShowWizard(false),
          entityId: selectedEntityId,
          geometry: selectedGeometry,
          onComplete: () => {
            setCheckingSub(true);
            api.getSubscriptionForEntity(selectedEntityId).then(setSubscription).finally(() => setCheckingSub(false));
          }
        }
      )
    ] });
  }
  if (subscription && (subscription.status === "syncing" || subscription.status === "created")) {
    return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-6 max-w-4xl mx-auto py-8", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex justify-between items-center", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-2xl font-bold text-slate-800", children: "Analytics Dashboard" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            onClick: () => setSelectedEntityId(null),
            className: "text-sm text-slate-500 hover:text-slate-700 underline",
            children: "Change Parcel"
          }
        )
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white rounded-xl shadow-sm border border-slate-200 p-12 text-center space-y-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-16 h-16 bg-blue-50 rounded-full flex items-center justify-center mx-auto text-blue-500 mb-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("svg", { className: "w-8 h-8 animate-spin", fill: "none", viewBox: "0 0 24 24", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("circle", { className: "opacity-25", cx: "12", cy: "12", r: "10", stroke: "currentColor", strokeWidth: "4" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("path", { className: "opacity-75", fill: "currentColor", d: "M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" })
        ] }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-xl font-semibold text-slate-900", children: "Procesando Histórico" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-slate-500 max-w-md mx-auto", children: "Estamos descargando y procesando imágenes históricas de Sentinel-2 para tu parcela. Esto puede tomar unos minutos." }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "pt-4 flex justify-center gap-2", children: /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-sm text-blue-600 font-medium bg-blue-50 px-3 py-1 rounded-full border border-blue-100", children: "Sincronizando..." }) })
      ] })
    ] });
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-6 max-w-4xl mx-auto py-8", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex justify-between items-center", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-2xl font-bold text-slate-800", children: "Analytics Dashboard" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "bg-green-100 text-green-800 text-xs px-2 py-1 rounded-full border border-green-200 flex items-center", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "w-2 h-2 bg-green-500 rounded-full mr-1 animate-pulse" }),
          "Monitoreo Activo"
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          onClick: () => setSelectedEntityId(null),
          className: "text-sm text-slate-500 hover:text-slate-700 underline",
          children: "Change Parcel"
        }
      )
    ] }),
    selectedIndex && ["NDVI", "EVI"].includes(selectedIndex) && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "bg-amber-50 border-l-4 border-amber-400 p-4 rounded-md mb-6", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex-shrink-0", children: /* @__PURE__ */ jsxRuntimeExports.jsx("svg", { className: "h-5 w-5 text-amber-400", viewBox: "0 0 20 20", fill: "currentColor", children: /* @__PURE__ */ jsxRuntimeExports.jsx("path", { fillRule: "evenodd", d: "M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z", clipRule: "evenodd" }) }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "ml-3", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-sm text-amber-700", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-bold", children: "Nota de Resolución:" }),
        ' Para entidades pequeñas (< 100m²), el índice Sentinel-2 representa "Vigor Zonal" y no salud individual precisa.'
      ] }) })
    ] }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { padding: "lg", className: "bg-white/90 backdrop-blur-md border border-slate-200/50 rounded-xl shadow-sm", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-4 flex justify-between items-center", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("h3", { className: "text-lg font-semibold text-slate-800", children: [
            "Tendencias de Vegetación (",
            selectedIndex || "NDVI",
            ")"
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-slate-500", children: "Evolución histórica del índice" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-xs text-slate-400", children: [
          "Última actualización: ",
          subscription?.last_run_at ? new Date(subscription.last_run_at).toLocaleDateString() : "Pendiente"
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "h-64 bg-slate-50 rounded-lg flex items-center justify-center", children: /* @__PURE__ */ jsxRuntimeExports.jsx(TimeseriesChart, { series: [], indexType: selectedIndex || "NDVI" }) })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-6", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { padding: "lg", className: "bg-white/90 backdrop-blur-md border border-slate-200/50 rounded-xl shadow-sm", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-4", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-md font-semibold text-slate-800", children: "Comparativa Anual" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500", children: "Mismo periodo en años anteriores" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "overflow-x-auto", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("table", { className: "min-w-full divide-y divide-gray-200", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("thead", { children: /* @__PURE__ */ jsxRuntimeExports.jsxs("tr", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider", children: "Año" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider", children: "Media" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "px-3 py-2 text-left text-xs font-medium text-gray-500 uppercase tracking-wider", children: "Dif." })
          ] }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("tbody", { className: "bg-white divide-y divide-gray-200", children: [2024, 2023, 2022].map((year, i) => /* @__PURE__ */ jsxRuntimeExports.jsxs("tr", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "px-3 py-2 whitespace-nowrap text-sm font-medium text-gray-900", children: year }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("td", { className: "px-3 py-2 whitespace-nowrap text-sm text-gray-500", children: [
              "0.",
              62 - i * 4
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: `px-3 py-2 whitespace-nowrap text-sm font-bold ${i === 0 ? "text-green-600" : "text-red-600"}`, children: i === 0 ? "+4%" : "-2%" })
          ] }, year)) })
        ] }) })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs(Card, { padding: "lg", className: "bg-white/90 backdrop-blur-md border border-slate-200/50 rounded-xl shadow-sm", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mb-4", children: /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-md font-semibold text-slate-800", children: "Estadísticas Rápidas" }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-2 gap-4", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-3 bg-green-50 rounded-lg border border-green-100", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "block text-xs text-green-600 uppercase font-bold", children: [
              "Max ",
              selectedIndex
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-2xl font-bold text-green-700", children: "0.86" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-3 bg-blue-50 rounded-lg border border-blue-100", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "block text-xs text-blue-600 uppercase font-bold", children: "Media" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-2xl font-bold text-blue-700", children: "0.62" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-3 bg-amber-50 rounded-lg border border-amber-100", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "block text-xs text-amber-600 uppercase font-bold", children: "Min" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-2xl font-bold text-amber-700", children: "0.12" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-3 bg-purple-50 rounded-lg border border-purple-100", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "block text-xs text-purple-600 uppercase font-bold", children: "Std Dev" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-2xl font-bold text-purple-700", children: "0.15" })
          ] })
        ] })
      ] })
    ] })
  ] });
};

export { VegetationAnalytics as V };
