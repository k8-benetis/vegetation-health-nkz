import { importShared } from './__federation_fn_import-Bs2X4leW.js';
import { u as useVegetationContext } from './vegetationContext-DfeO2cmt.js';

const {useEffect,useRef} = await importShared('react');
const VegetationLayer = ({ viewer }) => {
  const { selectedIndex, selectedDate, selectedSceneId } = useVegetationContext();
  const layerRef = useRef(null);
  const dataSourceRef = useRef(null);
  useEffect(() => {
    if (!viewer) {
      console.warn("[VegetationLayer] No viewer provided");
      return;
    }
    const Cesium = window.Cesium;
    if (!Cesium) return;
    if (layerRef.current) {
      viewer.imageryLayers.remove(layerRef.current);
      layerRef.current = null;
    }
    if (dataSourceRef.current) {
      viewer.dataSources.remove(dataSourceRef.current);
      dataSourceRef.current = null;
    }
    if (!selectedSceneId && !selectedIndex) return;
    if (selectedIndex === "VRA_ZONES" && selectedSceneId) {
      const geoJsonUrl = `/api/jobs/zoning/${selectedSceneId}/geojson`;
      console.log("[VegetationLayer] Loading VRA Zones:", geoJsonUrl);
      Cesium.GeoJsonDataSource.load(geoJsonUrl, {
        stroke: Cesium.Color.BLACK,
        fill: Cesium.Color.BLUE.withAlpha(0.5),
        strokeWidth: 3
      }).then((dataSource) => {
        if (viewer.isDestroyed()) return;
        const entities = dataSource.entities.values;
        for (let i = 0; i < entities.length; i++) {
          const entity = entities[i];
          const clusterId = entity.properties.cluster_id?.getValue();
          const colors = [
            Cesium.Color.RED.withAlpha(0.6),
            Cesium.Color.ORANGE.withAlpha(0.6),
            Cesium.Color.YELLOW.withAlpha(0.6),
            Cesium.Color.GREEN.withAlpha(0.6),
            Cesium.Color.BLUE.withAlpha(0.6)
          ];
          const color = colors[clusterId % colors.length] || Cesium.Color.GRAY.withAlpha(0.6);
          entity.polygon.material = color;
          entity.polygon.outline = true;
          entity.polygon.outlineColor = Cesium.Color.BLACK;
          entity.polygon.extrudedHeight = 10;
        }
        viewer.dataSources.add(dataSource);
        dataSourceRef.current = dataSource;
        viewer.flyTo(dataSource);
      }).catch((err) => {
        console.error("[VegetationLayer] Error loading zones:", err);
      });
      return;
    }
    if (selectedIndex && selectedSceneId) {
      const tileUrl = `/api/vegetation/tiles/{z}/{x}/{y}.png?scene_id=${selectedSceneId}&index_type=${selectedIndex}`;
      console.log("[VegetationLayer] Adding Raster Layer:", tileUrl);
      const provider = new Cesium.UrlTemplateImageryProvider({
        url: tileUrl,
        maximumLevel: 18,
        credit: "Vegetation Prime Module"
      });
      const layer = viewer.imageryLayers.addImageryProvider(provider);
      layer.alpha = 0.8;
      layerRef.current = layer;
    }
  }, [viewer, selectedIndex, selectedDate, selectedSceneId]);
  return null;
};

export { VegetationLayer, VegetationLayer as default };
