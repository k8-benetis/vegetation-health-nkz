import { importShared } from './__federation_fn_import-Bs2X4leW.js';
import { j as jsxRuntimeExports } from './jsx-runtime-CsM3lTE3.js';
import { u as useVegetationContext, V as VegetationProvider } from './vegetationContext-DfeO2cmt.js';
import { L as LoaderCircle, V as VegetationConfig } from './VegetationConfig-CT-kLWw1.js';
import { V as VegetationAnalytics } from './VegetationAnalytics-B80CTd5T.js';
import { c as createLucideIcon, u as useVegetationApi } from './createLucideIcon-e3PcgQAe.js';
import { g as getIndexInfo, L as Leaf } from './IndexPillSelector-CB09jkd_.js';
import { C as Calendar } from './calendar-BM24y3pm.js';
import { C as ChartColumn, E as Eye } from './eye-yuLgzYvZ.js';
import { L as Layers } from './layers-DK5sOaWK.js';

/**
 * @license lucide-react v0.424.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const ChevronDown = createLucideIcon("ChevronDown", [
  ["path", { d: "m6 9 6 6 6-6", key: "qrunsl" }]
]);

/**
 * @license lucide-react v0.424.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const ChevronRight = createLucideIcon("ChevronRight", [
  ["path", { d: "m9 18 6-6-6-6", key: "mthhwq" }]
]);

/**
 * @license lucide-react v0.424.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const Download = createLucideIcon("Download", [
  ["path", { d: "M21 15v4a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-4", key: "ih7n3h" }],
  ["polyline", { points: "7 10 12 15 17 10", key: "2ggqvy" }],
  ["line", { x1: "12", x2: "12", y1: "15", y2: "3", key: "1vk2je" }]
]);

/**
 * @license lucide-react v0.424.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const Filter = createLucideIcon("Filter", [
  ["polygon", { points: "22 3 2 3 10 12.46 10 19 14 21 14 12.46 22 3", key: "1yg77f" }]
]);

/**
 * @license lucide-react v0.424.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const Grid3x3 = createLucideIcon("Grid3x3", [
  ["rect", { width: "18", height: "18", x: "3", y: "3", rx: "2", key: "afitv7" }],
  ["path", { d: "M3 9h18", key: "1pudct" }],
  ["path", { d: "M3 15h18", key: "5xshup" }],
  ["path", { d: "M9 3v18", key: "fh3hqa" }],
  ["path", { d: "M15 3v18", key: "14nvp0" }]
]);

/**
 * @license lucide-react v0.424.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const List = createLucideIcon("List", [
  ["line", { x1: "8", x2: "21", y1: "6", y2: "6", key: "7ey8pc" }],
  ["line", { x1: "8", x2: "21", y1: "12", y2: "12", key: "rjfblc" }],
  ["line", { x1: "8", x2: "21", y1: "18", y2: "18", key: "c3b1m8" }],
  ["line", { x1: "3", x2: "3.01", y1: "6", y2: "6", key: "1g7gq3" }],
  ["line", { x1: "3", x2: "3.01", y1: "12", y2: "12", key: "1pjlvk" }],
  ["line", { x1: "3", x2: "3.01", y1: "18", y2: "18", key: "28t2mc" }]
]);

/**
 * @license lucide-react v0.424.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const MapPin = createLucideIcon("MapPin", [
  [
    "path",
    {
      d: "M20 10c0 4.993-5.539 10.193-7.399 11.799a1 1 0 0 1-1.202 0C9.539 20.193 4 14.993 4 10a8 8 0 0 1 16 0",
      key: "1r0f0z"
    }
  ],
  ["circle", { cx: "12", cy: "10", r: "3", key: "ilqhr7" }]
]);

/**
 * @license lucide-react v0.424.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const RefreshCw = createLucideIcon("RefreshCw", [
  ["path", { d: "M3 12a9 9 0 0 1 9-9 9.75 9.75 0 0 1 6.74 2.74L21 8", key: "v9h5vc" }],
  ["path", { d: "M21 3v5h-5", key: "1q7to0" }],
  ["path", { d: "M21 12a9 9 0 0 1-9 9 9.75 9.75 0 0 1-6.74-2.74L3 16", key: "3uifl3" }],
  ["path", { d: "M8 16H3v5", key: "1cv678" }]
]);

/**
 * @license lucide-react v0.424.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const Search = createLucideIcon("Search", [
  ["circle", { cx: "11", cy: "11", r: "8", key: "4ej97u" }],
  ["path", { d: "m21 21-4.3-4.3", key: "1qie3q" }]
]);

/**
 * @license lucide-react v0.424.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const Trash2 = createLucideIcon("Trash2", [
  ["path", { d: "M3 6h18", key: "d0wm0j" }],
  ["path", { d: "M19 6v14c0 1-1 2-2 2H7c-1 0-2-1-2-2V6", key: "4alrt4" }],
  ["path", { d: "M8 6V4c0-1 1-2 2-2h4c1 0 2 1 2 2v2", key: "v07s0e" }],
  ["line", { x1: "10", x2: "10", y1: "11", y2: "17", key: "1uufr5" }],
  ["line", { x1: "14", x2: "14", y1: "11", y2: "17", key: "xtxkd" }]
]);

const React = await importShared('react');
const CalculationCard = ({
  job,
  onViewInMap,
  onDownload,
  onDelete
}) => {
  const [showDownloadMenu, setShowDownloadMenu] = React.useState(false);
  const indexInfo = getIndexInfo(job.index_type || "NDVI");
  const histogramData = job.result_histogram || null;
  const formatDate = (dateStr) => {
    if (!dateStr) return "Fecha no disponible";
    const date = new Date(dateStr);
    return date.toLocaleDateString("es-ES", {
      day: "2-digit",
      month: "short",
      year: "numeric"
    });
  };
  const renderMiniHistogram = () => {
    if (!histogramData || !histogramData.bins || histogramData.bins.length === 0) {
      return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-end gap-0.5 h-8", children: [0.2, 0.4, 0.7, 0.9, 1, 0.8, 0.6, 0.3, 0.15].map((h, i) => /* @__PURE__ */ jsxRuntimeExports.jsx(
        "div",
        {
          className: "flex-1 rounded-t-sm transition-all",
          style: {
            height: `${h * 100}%`,
            backgroundColor: indexInfo?.color || "#22c55e",
            opacity: 0.3 + i / 10 * 0.7
          }
        },
        i
      )) });
    }
    const maxCount = Math.max(...histogramData.counts);
    return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-end gap-0.5 h-8", children: histogramData.counts.slice(0, 10).map((count, i) => /* @__PURE__ */ jsxRuntimeExports.jsx(
      "div",
      {
        className: "flex-1 rounded-t-sm transition-all hover:opacity-80",
        style: {
          height: `${count / maxCount * 100}%`,
          backgroundColor: indexInfo?.color || "#22c55e",
          minHeight: "2px"
        }
      },
      i
    )) });
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white rounded-xl border border-slate-200 shadow-sm hover:shadow-md transition-shadow overflow-hidden", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-4 py-3 border-b border-slate-100 flex items-center justify-between", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "span",
          {
            className: "px-2.5 py-1 rounded-full text-xs font-bold text-white",
            style: { backgroundColor: indexInfo?.color || "#22c55e" },
            children: job.index_type || "NDVI"
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs text-slate-500", children: job.status === "completed" ? "✓ Completado" : job.status })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1 text-xs text-slate-400", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Calendar, { className: "w-3 h-3" }),
        formatDate(job.created_at)
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-4 space-y-3", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(MapPin, { className: "w-4 h-4 text-slate-400" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-sm font-medium text-slate-800 truncate", children: job.entity_name || job.entity_id || "Zona personalizada" })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-slate-50 rounded-lg p-3", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1 text-xs text-slate-500 mb-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(ChartColumn, { className: "w-3 h-3" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Distribución de valores" })
        ] }),
        renderMiniHistogram(),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex justify-between text-[10px] text-slate-400 mt-1", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "-1" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "0" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "+1" })
        ] })
      ] }),
      job.result_stats && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-3 gap-2 text-center", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-slate-50 rounded-lg p-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[10px] text-slate-500", children: "Media" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-sm font-semibold text-slate-800", children: job.result_stats.mean?.toFixed(3) || "-" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-slate-50 rounded-lg p-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[10px] text-slate-500", children: "Mín" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-sm font-semibold text-slate-800", children: job.result_stats.min?.toFixed(3) || "-" })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-slate-50 rounded-lg p-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-[10px] text-slate-500", children: "Máx" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-sm font-semibold text-slate-800", children: job.result_stats.max?.toFixed(3) || "-" })
        ] })
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "px-4 py-3 bg-slate-50 border-t border-slate-100 flex items-center justify-between", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            onClick: () => onViewInMap?.(job),
            className: "flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-green-700 bg-green-100 hover:bg-green-200 rounded-lg transition-colors",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Eye, { className: "w-3.5 h-3.5" }),
              "Ver en mapa"
            ]
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            onClick: () => {
              if (window.confirm("¿Eliminar este cálculo del historial?")) {
                onDelete?.(job);
              }
            },
            className: "flex items-center gap-1.5 px-2 py-1.5 text-xs font-medium text-red-600 hover:bg-red-50 rounded-lg transition-colors",
            title: "Eliminar cálculo",
            children: /* @__PURE__ */ jsxRuntimeExports.jsx(Trash2, { className: "w-3.5 h-3.5" })
          }
        )
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "button",
          {
            onClick: () => setShowDownloadMenu(!showDownloadMenu),
            className: "flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-slate-700 bg-white border border-slate-200 hover:bg-slate-50 rounded-lg transition-colors",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Download, { className: "w-3.5 h-3.5" }),
              "Descargar",
              /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronDown, { className: "w-3 h-3" })
            ]
          }
        ),
        showDownloadMenu && /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "div",
          {
            className: "absolute right-0 bottom-full mb-1 bg-white border border-slate-200 rounded-lg shadow-lg py-1 min-w-[140px] z-10",
            onMouseLeave: () => setShowDownloadMenu(false),
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs(
                "button",
                {
                  onClick: () => {
                    onDownload?.(job, "geotiff");
                    setShowDownloadMenu(false);
                  },
                  className: "w-full px-3 py-2 text-left text-xs hover:bg-slate-50 flex items-center gap-2",
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "w-8 text-[10px] font-mono bg-slate-100 px-1 rounded", children: "TIFF" }),
                    "GeoTIFF (Raster)"
                  ]
                }
              ),
              /* @__PURE__ */ jsxRuntimeExports.jsxs(
                "button",
                {
                  onClick: () => {
                    onDownload?.(job, "png");
                    setShowDownloadMenu(false);
                  },
                  className: "w-full px-3 py-2 text-left text-xs hover:bg-slate-50 flex items-center gap-2",
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "w-8 text-[10px] font-mono bg-slate-100 px-1 rounded", children: "PNG" }),
                    "Imagen PNG"
                  ]
                }
              ),
              /* @__PURE__ */ jsxRuntimeExports.jsxs(
                "button",
                {
                  onClick: () => {
                    onDownload?.(job, "csv");
                    setShowDownloadMenu(false);
                  },
                  className: "w-full px-3 py-2 text-left text-xs hover:bg-slate-50 flex items-center gap-2",
                  children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "w-8 text-[10px] font-mono bg-slate-100 px-1 rounded", children: "CSV" }),
                    "Estadísticas CSV"
                  ]
                }
              )
            ]
          }
        )
      ] })
    ] })
  ] });
};

const {useState: useState$1,useEffect: useEffect$1} = await importShared('react');
const CalculationsPage = ({
  onViewInMap
}) => {
  const api = useVegetationApi();
  const { setSelectedEntityId, setSelectedSceneId } = useVegetationContext();
  const [jobs, setJobs] = useState$1([]);
  const [loading, setLoading] = useState$1(true);
  const [error, setError] = useState$1(null);
  const [viewMode, setViewMode] = useState$1("grid");
  const [filterIndex, setFilterIndex] = useState$1("all");
  const [searchQuery, setSearchQuery] = useState$1("");
  const fetchJobs = async () => {
    setLoading(true);
    setError(null);
    try {
      const response = await api.listJobs("completed", 50, 0);
      if (response && response.jobs) {
        setJobs(response.jobs);
      }
    } catch (err) {
      console.error("Error fetching jobs:", err);
      setError("Error al cargar los cálculos");
    } finally {
      setLoading(false);
    }
  };
  useEffect$1(() => {
    fetchJobs();
  }, []);
  const handleViewInMap = (job) => {
    if (job.entity_id) {
      setSelectedEntityId(job.entity_id);
    }
    if (job.scene_id) {
      setSelectedSceneId(job.scene_id);
    }
    onViewInMap?.(job);
  };
  const handleDownload = async (job, format) => {
    try {
      if (job.result_url) {
        const downloadUrl = format === "geotiff" ? job.result_url : `${job.result_url.replace(".tif", `.${format}`)}`;
        window.open(downloadUrl, "_blank");
      } else {
        const blob = await api.downloadResult(job.id, format);
        const url = URL.createObjectURL(blob);
        const a = document.createElement("a");
        a.href = url;
        a.download = `${job.index_type}_${job.entity_id || "area"}_${job.created_at?.split("T")[0]}.${format}`;
        a.click();
        URL.revokeObjectURL(url);
      }
    } catch (err) {
      console.error("Download error:", err);
      alert("Error al descargar el archivo");
    }
  };
  const filteredJobs = jobs.filter((job) => {
    const matchesIndex = filterIndex === "all" || job.index_type === filterIndex;
    const matchesSearch = !searchQuery || job.entity_name?.toLowerCase().includes(searchQuery.toLowerCase()) || job.entity_id?.toLowerCase().includes(searchQuery.toLowerCase());
    return matchesIndex && matchesSearch;
  });
  const indexTypes = ["all", ...new Set(jobs.map((j) => j.index_type).filter(Boolean))];
  const handleDelete = async (job) => {
    try {
      await api.deleteJob(job.id);
      setJobs((prev) => prev.filter((j) => j.id !== job.id));
    } catch (err) {
      console.error("Delete error:", err);
      alert("Error al eliminar el cálculo");
    }
  };
  if (loading) {
    return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center justify-center h-64", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-center", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "w-8 h-8 animate-spin text-green-600 mx-auto mb-2" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-slate-500", children: "Cargando cálculos..." })
    ] }) });
  }
  if (error) {
    return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center justify-center h-64", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-center", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-red-500 mb-4", children: error }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          onClick: fetchJobs,
          className: "px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700",
          children: "Reintentar"
        }
      )
    ] }) });
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-6 max-w-7xl mx-auto", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-6", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "text-2xl font-bold text-slate-900 mb-2", children: "Historial de Cálculos" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-slate-600", children: "Visualiza y descarga los análisis de vegetación realizados anteriormente." })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white rounded-xl border border-slate-200 p-4 mb-6 flex flex-wrap items-center gap-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex-1 min-w-[200px] relative", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Search, { className: "absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "input",
          {
            type: "text",
            placeholder: "Buscar por parcela...",
            value: searchQuery,
            onChange: (e) => setSearchQuery(e.target.value),
            className: "w-full pl-9 pr-4 py-2 text-sm border border-slate-200 rounded-lg focus:outline-none focus:ring-2 focus:ring-green-500 focus:border-transparent"
          }
        )
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(Filter, { className: "w-4 h-4 text-slate-400" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "select",
          {
            value: filterIndex,
            onChange: (e) => setFilterIndex(e.target.value),
            className: "text-sm border border-slate-200 rounded-lg px-3 py-2 focus:outline-none focus:ring-2 focus:ring-green-500",
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "all", children: "Todos los índices" }),
              indexTypes.filter((t) => t !== "all").map((type) => /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: type, children: type }, type))
            ]
          }
        )
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center bg-slate-100 rounded-lg p-1", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            onClick: () => setViewMode("grid"),
            className: `p-2 rounded-md transition-colors ${viewMode === "grid" ? "bg-white shadow-sm text-green-700" : "text-slate-500"}`,
            title: "Vista cuadrícula",
            children: /* @__PURE__ */ jsxRuntimeExports.jsx(Grid3x3, { className: "w-4 h-4" })
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            onClick: () => setViewMode("list"),
            className: `p-2 rounded-md transition-colors ${viewMode === "list" ? "bg-white shadow-sm text-green-700" : "text-slate-500"}`,
            title: "Vista lista",
            children: /* @__PURE__ */ jsxRuntimeExports.jsx(List, { className: "w-4 h-4" })
          }
        )
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          onClick: fetchJobs,
          className: "p-2 text-slate-500 hover:text-green-600 hover:bg-slate-100 rounded-lg transition-colors",
          title: "Actualizar",
          children: /* @__PURE__ */ jsxRuntimeExports.jsx(RefreshCw, { className: "w-4 h-4" })
        }
      )
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-4 text-sm text-slate-500", children: [
      filteredJobs.length,
      " ",
      filteredJobs.length === 1 ? "resultado" : "resultados",
      filterIndex !== "all" && ` para ${filterIndex}`
    ] }),
    filteredJobs.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white rounded-xl border border-slate-200 p-12 text-center", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "w-16 h-16 bg-slate-100 rounded-full flex items-center justify-center mx-auto mb-4", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Search, { className: "w-8 h-8 text-slate-400" }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-lg font-medium text-slate-800 mb-2", children: "No hay cálculos" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-slate-500", children: searchQuery || filterIndex !== "all" ? "No se encontraron cálculos con los filtros aplicados." : "Aún no has realizado ningún análisis de vegetación." })
    ] }) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: viewMode === "grid" ? "grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4" : "flex flex-col gap-3", children: filteredJobs.map((job) => /* @__PURE__ */ jsxRuntimeExports.jsx(
      CalculationCard,
      {
        job,
        onViewInMap: handleViewInMap,
        onDownload: handleDownload,
        onDelete: handleDelete
      },
      job.id
    )) })
  ] });
};

const {useState,useEffect} = await importShared('react');

const {Card} = await importShared('@nekazari/ui-kit');
const DashboardContent = () => {
  const {
    selectedEntityId,
    setSelectedEntityId
  } = useVegetationContext();
  const api = useVegetationApi();
  const [parcels, setParcels] = useState([]);
  const [loadingContext, setLoadingContext] = useState(true);
  const [activeTab, setActiveTab] = useState("dashboard");
  useEffect(() => {
    setLoadingContext(true);
    api.listTenantParcels().then((data) => {
      setParcels(data);
    }).catch(console.error).finally(() => setLoadingContext(false));
  }, []);
  useEffect(() => {
    if (selectedEntityId && activeTab === "dashboard") {
      setActiveTab("analytics");
    }
  }, [selectedEntityId]);
  const handleBackToDashboard = () => {
    setSelectedEntityId(null);
    setActiveTab("dashboard");
  };
  if (activeTab === "dashboard") {
    return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-6 max-w-7xl mx-auto space-y-6", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("header", { className: "mb-8", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "text-2xl font-bold text-slate-900", children: "Gestión de Cultivos (Vegetation Prime)" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-slate-600", children: "Selecciona una parcela para analizar su salud vegetativa." })
      ] }),
      loadingContext ? /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-center py-12", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "animate-spin w-8 h-8 border-4 border-green-600 border-t-transparent rounded-full mx-auto mb-4" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-slate-500", children: "Cargando parcelas..." })
      ] }) : /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid grid-cols-1 gap-4", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Card, { className: "overflow-hidden", children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "overflow-x-auto", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("table", { className: "w-full text-left text-sm text-slate-600", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("thead", { className: "bg-slate-50 text-slate-900 font-semibold border-b border-slate-200", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("tr", { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "p-4", children: "Nombre de Parcela" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "p-4", children: "Cultivo Detectado" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "p-4", children: "Área (ha)" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("th", { className: "p-4 text-right", children: "Acción" })
        ] }) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("tbody", { className: "divide-y divide-slate-100", children: [
          Array.isArray(parcels) && parcels.map((parcel) => {
            const parcelName = parcel.name?.value || parcel.name || parcel.id;
            const cropSpecies = parcel.cropSpecies?.value || parcel.category?.value || "Sin asignar";
            const area = parcel.area?.value || parcel.area;
            return /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "tr",
              {
                className: "hover:bg-slate-50 transition-colors cursor-pointer",
                onClick: () => setSelectedEntityId(parcel.id),
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("td", { className: "p-4 font-medium text-slate-900 flex items-center gap-3", children: [
                    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "p-2 bg-green-100 text-green-700 rounded-lg", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Leaf, { className: "w-4 h-4" }) }),
                    parcelName
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "p-4", children: cropSpecies }),
                  /* @__PURE__ */ jsxRuntimeExports.jsxs("td", { className: "p-4", children: [
                    area ? (Number(area) / 1e4).toFixed(2) : "-",
                    " ha"
                  ] }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("td", { className: "p-4 text-right", children: /* @__PURE__ */ jsxRuntimeExports.jsxs(
                    "button",
                    {
                      className: "text-white bg-green-600 hover:bg-green-700 px-3 py-1.5 rounded-md text-xs font-medium inline-flex items-center gap-1 transition-colors",
                      onClick: (e) => {
                        e.stopPropagation();
                        setSelectedEntityId(parcel.id);
                      },
                      children: [
                        "Analizar ",
                        /* @__PURE__ */ jsxRuntimeExports.jsx(ChevronRight, { className: "w-3 h-3" })
                      ]
                    }
                  ) })
                ]
              },
              parcel.id
            );
          }),
          parcels.length === 0 && /* @__PURE__ */ jsxRuntimeExports.jsx("tr", { children: /* @__PURE__ */ jsxRuntimeExports.jsx("td", { colSpan: 4, className: "p-8 text-center text-slate-400", children: "No se encontraron parcelas asociadas a tu cuenta." }) })
        ] })
      ] }) }) }) })
    ] });
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "h-full flex flex-col", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white border-b border-gray-200 px-6 py-3 flex items-center justify-between", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-4", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            onClick: handleBackToDashboard,
            className: "text-slate-500 hover:text-slate-900 font-medium text-sm flex items-center gap-1",
            children: "← Volver al listado"
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "h-4 w-px bg-gray-300" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "font-semibold text-slate-800", children: parcels.find((p) => p.id === selectedEntityId)?.name || (activeTab === "analytics" ? "Análisis detallado" : "Configuración") })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex bg-slate-100 p-1 rounded-lg", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            onClick: () => setActiveTab("analytics"),
            className: `px-3 py-1.5 text-sm font-medium rounded-md transition-all ${activeTab === "analytics" ? "bg-white text-green-700 shadow-sm" : "text-slate-600 hover:text-slate-900"}`,
            children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Layers, { className: "w-4 h-4" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Análisis" })
            ] })
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            onClick: () => setActiveTab("config"),
            className: `px-3 py-1.5 text-sm font-medium rounded-md transition-all ${activeTab === "config" ? "bg-white text-green-700 shadow-sm" : "text-slate-600 hover:text-slate-900"}`,
            children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Calendar, { className: "w-4 h-4" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Configuración" })
            ] })
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            onClick: () => setActiveTab("calculations"),
            className: `px-3 py-1.5 text-sm font-medium rounded-md transition-all ${activeTab === "calculations" ? "bg-white text-green-700 shadow-sm" : "text-slate-600 hover:text-slate-900"}`,
            children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(ChartColumn, { className: "w-4 h-4" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Cálculos" })
            ] })
          }
        )
      ] })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex-1 overflow-auto bg-slate-50", children: activeTab === "analytics" ? /* @__PURE__ */ jsxRuntimeExports.jsx(VegetationAnalytics, {}) : activeTab === "calculations" ? /* @__PURE__ */ jsxRuntimeExports.jsx(CalculationsPage, {}) : /* @__PURE__ */ jsxRuntimeExports.jsx(VegetationConfig, { mode: "page" }) })
  ] });
};
const App = () => {
  return /* @__PURE__ */ jsxRuntimeExports.jsx(VegetationProvider, { children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "bg-slate-50 text-slate-900 font-sans", children: /* @__PURE__ */ jsxRuntimeExports.jsx(DashboardContent, {}) }) });
};

export { App as default };
