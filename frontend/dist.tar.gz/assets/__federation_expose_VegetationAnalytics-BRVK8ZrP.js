import { V as VegetationAnalytics } from './VegetationAnalytics-B80CTd5T.js';



export { VegetationAnalytics, VegetationAnalytics as default };
