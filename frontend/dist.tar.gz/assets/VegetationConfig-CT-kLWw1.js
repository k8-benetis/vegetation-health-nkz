import { importShared } from './__federation_fn_import-Bs2X4leW.js';
import { j as jsxRuntimeExports } from './jsx-runtime-CsM3lTE3.js';
import { u as useVegetationContext } from './vegetationContext-DfeO2cmt.js';
import { u as useVegetationApi, c as createLucideIcon } from './createLucideIcon-e3PcgQAe.js';
import { A as Activity, C as CircleCheckBig } from './circle-check-big-FchppnUZ.js';
import { L as Leaf, I as IndexPillSelector } from './IndexPillSelector-CB09jkd_.js';

const {useState: useState$4,useEffect: useEffect$2,useCallback: useCallback$2} = await importShared('react');
function useVegetationJobs(options = {}) {
  const {
    statusFilter = "all",
    limit = 50,
    autoRefresh = false,
    refreshInterval = 3e4
    // 30 seconds
  } = options;
  const api = useVegetationApi();
  const [jobs, setJobs] = useState$4([]);
  const [loading, setLoading] = useState$4(true);
  const [error, setError] = useState$4(null);
  const loadJobs = useCallback$2(async () => {
    try {
      setLoading(true);
      setError(null);
      const data = await api.listJobs(statusFilter !== "all" ? statusFilter : void 0, limit, 0);
      setJobs(data?.jobs || []);
    } catch (err) {
      console.error("[useVegetationJobs] Error loading jobs:", err);
      setError(err instanceof Error ? err.message : "Failed to load jobs");
      setJobs([]);
    } finally {
      setLoading(false);
    }
  }, [api, statusFilter, limit]);
  useEffect$2(() => {
    loadJobs();
  }, [loadJobs]);
  useEffect$2(() => {
    if (!autoRefresh) return;
    const interval = setInterval(() => {
      loadJobs();
    }, refreshInterval);
    return () => clearInterval(interval);
  }, [autoRefresh, refreshInterval, loadJobs]);
  const statistics = {
    total: jobs.length,
    completed: jobs.filter((j) => j.status === "completed").length,
    failed: jobs.filter((j) => j.status === "failed").length,
    running: jobs.filter((j) => j.status === "running").length,
    pending: jobs.filter((j) => j.status === "pending").length
  };
  return {
    jobs,
    loading,
    error,
    statistics,
    refresh: loadJobs
  };
}

const {useState: useState$3,useEffect: useEffect$1,useCallback: useCallback$1} = await importShared('react');
function useVegetationConfig() {
  const api = useVegetationApi();
  const [config, setConfig] = useState$3({});
  const [loading, setLoading] = useState$3(true);
  const [saving, setSaving] = useState$3(false);
  const [error, setError] = useState$3(null);
  const [success, setSuccess] = useState$3(false);
  const [credentialsStatus, setCredentialsStatus] = useState$3(null);
  const [credentialsLoading, setCredentialsLoading] = useState$3(false);
  const [usage, setUsage] = useState$3(null);
  const { jobs: recentJobs, loading: jobsLoading, refresh: refreshJobs } = useVegetationJobs({
    statusFilter: "all",
    limit: 5
  });
  const loadConfig = useCallback$1(async () => {
    try {
      setLoading(true);
      setError(null);
      const data = await api.getConfig();
      setConfig(data);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Failed to load configuration");
    } finally {
      setLoading(false);
    }
  }, [api]);
  const loadCredentialsStatus = useCallback$1(async () => {
    try {
      setCredentialsLoading(true);
      const status = await api.getCredentialsStatus();
      setCredentialsStatus(status);
    } catch (err) {
      console.error("[useVegetationConfig] Error loading credentials status:", err);
      setCredentialsStatus({
        available: false,
        source: null,
        message: "Error al verificar el estado de las credenciales"
      });
    } finally {
      setCredentialsLoading(false);
    }
  }, [api]);
  const loadUsage = useCallback$1(async () => {
    try {
      const data = await api.getCurrentUsage();
      setUsage(data);
    } catch (err) {
      console.error("[useVegetationConfig] Error loading usage:", err);
    }
  }, [api]);
  const saveConfig = useCallback$1(async (configToSave) => {
    try {
      setSaving(true);
      setError(null);
      setSuccess(false);
      await api.updateConfig(configToSave);
      setSuccess(true);
      await loadConfig();
      refreshJobs();
      loadCredentialsStatus();
      setTimeout(() => setSuccess(false), 3e3);
    } catch (err) {
      console.error("[useVegetationConfig] Error saving config:", err);
      if (err?.response?.status === 405) {
        setError("Método no permitido. Por favor, verifique la configuración del servidor.");
      } else if (err?.response?.status === 401) {
        setError("No autorizado. Por favor, inicie sesión nuevamente.");
      } else if (err?.response?.status === 400) {
        setError(err?.response?.data?.detail || "Datos inválidos. Por favor, verifique los valores ingresados.");
      } else {
        setError(err?.message || err?.toString() || "Error al guardar la configuración. Por favor, intente nuevamente.");
      }
    } finally {
      setSaving(false);
    }
  }, [api, loadConfig, refreshJobs, loadCredentialsStatus]);
  useEffect$1(() => {
    loadConfig();
    loadUsage();
    loadCredentialsStatus();
  }, [loadConfig, loadUsage, loadCredentialsStatus]);
  const downloadJobs = recentJobs.filter((j) => j.job_type === "download");
  return {
    config,
    loading,
    saving,
    error,
    success,
    credentialsStatus,
    credentialsLoading,
    usage,
    recentJobs: downloadJobs,
    jobsLoading,
    saveConfig,
    refresh: loadConfig,
    refreshCredentials: loadCredentialsStatus,
    refreshUsage: loadUsage,
    refreshJobs
  };
}

/**
 * @license lucide-react v0.424.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const Calculator = createLucideIcon("Calculator", [
  ["rect", { width: "16", height: "20", x: "4", y: "2", rx: "2", key: "1nb95v" }],
  ["line", { x1: "8", x2: "16", y1: "6", y2: "6", key: "x4nwl0" }],
  ["line", { x1: "16", x2: "16", y1: "14", y2: "18", key: "wjye3r" }],
  ["path", { d: "M16 10h.01", key: "1m94wz" }],
  ["path", { d: "M12 10h.01", key: "1nrarc" }],
  ["path", { d: "M8 10h.01", key: "19clt8" }],
  ["path", { d: "M12 14h.01", key: "1etili" }],
  ["path", { d: "M8 14h.01", key: "6423bh" }],
  ["path", { d: "M12 18h.01", key: "mhygvu" }],
  ["path", { d: "M8 18h.01", key: "lrp35t" }]
]);

/**
 * @license lucide-react v0.424.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const CircleAlert = createLucideIcon("CircleAlert", [
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
  ["line", { x1: "12", x2: "12", y1: "8", y2: "12", key: "1pkeuh" }],
  ["line", { x1: "12", x2: "12.01", y1: "16", y2: "16", key: "4dfq90" }]
]);

/**
 * @license lucide-react v0.424.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const Droplets = createLucideIcon("Droplets", [
  [
    "path",
    {
      d: "M7 16.3c2.2 0 4-1.83 4-4.05 0-1.16-.57-2.26-1.71-3.19S7.29 6.75 7 5.3c-.29 1.45-1.14 2.84-2.29 3.76S3 11.1 3 12.25c0 2.22 1.8 4.05 4 4.05z",
      key: "1ptgy4"
    }
  ],
  [
    "path",
    {
      d: "M12.56 6.6A10.97 10.97 0 0 0 14 3.02c.5 2.5 2 4.9 4 6.5s3 3.5 3 5.5a6.98 6.98 0 0 1-11.91 4.97",
      key: "1sl1rz"
    }
  ]
]);

/**
 * @license lucide-react v0.424.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const LoaderCircle = createLucideIcon("LoaderCircle", [
  ["path", { d: "M21 12a9 9 0 1 1-6.219-8.56", key: "13zald" }]
]);

/**
 * @license lucide-react v0.424.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const Map = createLucideIcon("Map", [
  [
    "path",
    {
      d: "M14.106 5.553a2 2 0 0 0 1.788 0l3.659-1.83A1 1 0 0 1 21 4.619v12.764a1 1 0 0 1-.553.894l-4.553 2.277a2 2 0 0 1-1.788 0l-4.212-2.106a2 2 0 0 0-1.788 0l-3.659 1.83A1 1 0 0 1 3 19.381V6.618a1 1 0 0 1 .553-.894l4.553-2.277a2 2 0 0 1 1.788 0z",
      key: "169xi5"
    }
  ],
  ["path", { d: "M15 5.764v15", key: "1pn4in" }],
  ["path", { d: "M9 3.236v15", key: "1uimfh" }]
]);

/**
 * @license lucide-react v0.424.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const Sprout = createLucideIcon("Sprout", [
  ["path", { d: "M7 20h10", key: "e6iznv" }],
  ["path", { d: "M10 20c5.5-2.5.8-6.4 3-10", key: "161w41" }],
  [
    "path",
    {
      d: "M9.5 9.4c1.1.8 1.8 2.2 2.3 3.7-2 .4-3.5.4-4.8-.3-1.2-.6-2.3-1.9-3-4.2 2.8-.5 4.4 0 5.5.8z",
      key: "9gtqwd"
    }
  ],
  [
    "path",
    {
      d: "M14.1 6a7 7 0 0 0-1.1 4c1.9-.1 3.3-.6 4.3-1.4 1-1 1.6-2.3 1.7-4.6-2.7.1-4 1-4.9 2z",
      key: "bkxnd2"
    }
  ]
]);

/**
 * @license lucide-react v0.424.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const Waves = createLucideIcon("Waves", [
  [
    "path",
    {
      d: "M2 6c.6.5 1.2 1 2.5 1C7 7 7 5 9.5 5c2.6 0 2.4 2 5 2 2.5 0 2.5-2 5-2 1.3 0 1.9.5 2.5 1",
      key: "knzxuh"
    }
  ],
  [
    "path",
    {
      d: "M2 12c.6.5 1.2 1 2.5 1 2.5 0 2.5-2 5-2 2.6 0 2.4 2 5 2 2.5 0 2.5-2 5-2 1.3 0 1.9.5 2.5 1",
      key: "2jd2cc"
    }
  ],
  [
    "path",
    {
      d: "M2 18c.6.5 1.2 1 2.5 1 2.5 0 2.5-2 5-2 2.6 0 2.4 2 5 2 2.5 0 2.5-2 5-2 1.3 0 1.9.5 2.5 1",
      key: "rd2r6e"
    }
  ]
]);

const MODES = [
  {
    id: "health",
    label: "Salud del Cultivo",
    description: "Vigor general (NDVI)",
    icon: Activity,
    indexType: "NDVI",
    color: "text-green-600",
    bgColor: "bg-green-50"
  },
  {
    id: "water",
    label: "Estrés Hídrico",
    description: "Humedad (NDMI)",
    icon: Droplets,
    indexType: "NDMI",
    color: "text-blue-600",
    bgColor: "bg-blue-50"
  },
  {
    id: "radar",
    label: "Humedad Suelo",
    description: "Radar Sentinel-1 (SAMI)",
    icon: Waves,
    indexType: "SAMI",
    color: "text-indigo-600",
    bgColor: "bg-indigo-50"
  },
  {
    id: "nutrition",
    label: "Nutrición",
    description: "Clorofila (NDRE)",
    icon: Leaf,
    indexType: "NDRE",
    color: "text-amber-600",
    bgColor: "bg-amber-50"
  },
  {
    id: "woody",
    label: "Leñosos",
    description: "Suelo visible (SAVI)",
    icon: Sprout,
    indexType: "SAVI",
    color: "text-emerald-600",
    bgColor: "bg-emerald-50"
  },
  {
    id: "zoning",
    label: "Zonificación",
    description: "VRA Clusters (IA)",
    icon: Map,
    indexType: "VRA_ZONES",
    color: "text-purple-600",
    bgColor: "bg-purple-50"
  }
];
const ModeSelector = ({
  currentIndex,
  onChange,
  disabled = false
}) => {
  return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "grid grid-cols-2 gap-2", children: MODES.map((mode) => {
    const isSelected = currentIndex === mode.indexType;
    const Icon = mode.icon;
    return /* @__PURE__ */ jsxRuntimeExports.jsxs(
      "button",
      {
        onClick: () => onChange(mode.indexType),
        disabled,
        className: `
              relative p-3 rounded-xl border text-left transition-all duration-200
              ${isSelected ? `border-${mode.color.split("-")[1]}-500 ring-1 ring-${mode.color.split("-")[1]}-500 ${mode.bgColor}` : "border-slate-200 hover:border-slate-300 hover:bg-slate-50"}
              ${disabled ? "opacity-50 cursor-not-allowed" : "cursor-pointer"}
            `,
        children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `
              w-8 h-8 rounded-lg flex items-center justify-center mb-2
              ${isSelected ? "bg-white shadow-sm" : "bg-white border border-slate-100"}
            `, children: /* @__PURE__ */ jsxRuntimeExports.jsx(Icon, { className: `w-5 h-5 ${mode.color}` }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-0.5", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("h4", { className: `font-semibold text-sm ${isSelected ? "text-slate-800" : "text-slate-700"}`, children: mode.label }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500", children: mode.description })
          ] }),
          isSelected && /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `absolute top-2 right-2 w-2 h-2 rounded-full bg-${mode.color.split("-")[1]}-500` })
        ]
      },
      mode.id
    );
  }) });
};

const {useState: useState$2,useCallback} = await importShared('react');
function useIndexCalculation() {
  const api = useVegetationApi();
  const { selectedSceneId, selectedEntityId } = useVegetationContext();
  const [state, setState] = useState$2({
    isCalculating: false,
    jobId: null,
    error: null,
    success: false
  });
  const calculateIndex = useCallback(
    async (options) => {
      const calculationOptions = {
        sceneId: options?.sceneId || selectedSceneId || void 0,
        indexType: options?.indexType || "NDVI",
        entityId: options?.entityId || selectedEntityId || void 0,
        formula: options?.formula,
        startDate: options?.startDate,
        endDate: options?.endDate
      };
      if (!calculationOptions.sceneId && (!calculationOptions.startDate || !calculationOptions.endDate)) {
        setState({
          isCalculating: false,
          jobId: null,
          error: "Please select a scene OR provide a date range used.",
          success: false
        });
        return null;
      }
      setState({
        isCalculating: true,
        jobId: null,
        error: null,
        success: false
      });
      try {
        const result = await api.calculateIndex({
          scene_id: calculationOptions.sceneId,
          index_type: calculationOptions.indexType,
          entity_id: calculationOptions.entityId,
          formula: calculationOptions.formula,
          start_date: calculationOptions.startDate,
          end_date: calculationOptions.endDate
        });
        const jobId = result.job_id;
        let attempts = 0;
        const maxAttempts = 60;
        let lastStatus = "pending";
        while (attempts < maxAttempts) {
          await new Promise((r) => setTimeout(r, 1e3));
          try {
            const jobDetails = await api.getJobDetails(jobId);
            if (!jobDetails || !jobDetails.job) {
              console.warn("Poll: job details not available yet, retrying...");
              attempts++;
              continue;
            }
            lastStatus = jobDetails.job.status;
            if (lastStatus === "completed") {
              break;
            } else if (lastStatus === "failed") {
              const errorMsg = jobDetails.job.error_message || "El cálculo falló en el servidor";
              throw new Error(errorMsg);
            }
          } catch (pollError) {
            if (pollError.message && !pollError.message.includes("Poll")) {
              throw pollError;
            }
            console.warn("Poll error:", pollError.message);
          }
          attempts++;
        }
        if (attempts >= maxAttempts && lastStatus !== "completed") {
          throw new Error(`El cálculo tardó demasiado (último estado: ${lastStatus}). Revisa los logs del servidor.`);
        }
        setState({
          isCalculating: false,
          jobId,
          error: null,
          success: true
        });
        return jobId;
      } catch (err) {
        const errorMessage = err instanceof Error ? err.message : "Failed to calculate index";
        setState({
          isCalculating: false,
          jobId: null,
          error: errorMessage,
          success: false
        });
        return null;
      }
    },
    [api, selectedSceneId, selectedEntityId]
  );
  const resetState = useCallback(() => {
    setState({
      isCalculating: false,
      jobId: null,
      error: null,
      success: false
    });
  }, []);
  return {
    calculateIndex,
    resetState,
    ...state
  };
}

const CalculationButton = ({
  sceneId,
  entityId,
  indexType,
  variant = "primary",
  size = "md",
  className = "",
  startDate,
  endDate,
  formula
}) => {
  const { selectedIndex, selectedSceneId, selectedEntityId, setSelectedIndex } = useVegetationContext();
  const { calculateIndex, isCalculating, error, success, resetState } = useIndexCalculation();
  const effectiveSceneId = sceneId || selectedSceneId;
  const effectiveEntityId = entityId || selectedEntityId;
  const effectiveIndexType = indexType || selectedIndex;
  const handleClick = async () => {
    resetState();
    const jobId = await calculateIndex({
      sceneId: effectiveSceneId || void 0,
      entityId: effectiveEntityId || void 0,
      indexType: effectiveIndexType,
      startDate,
      endDate,
      formula
    });
    if (jobId && setSelectedIndex) {
      console.log("[CalculationButton] Calculation success, refreshing map layer:", effectiveIndexType);
      setSelectedIndex(effectiveIndexType);
    }
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col gap-2", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      "button",
      {
        onClick: handleClick,
        disabled: isCalculating || !effectiveSceneId && !startDate,
        className: `
          px-4 py-2 rounded-md font-medium transition-all
          disabled:opacity-50 disabled:cursor-not-allowed
          flex items-center gap-2 justify-center
          ${variant === "primary" ? "bg-blue-600 text-white hover:bg-blue-700 active:bg-blue-800" : "bg-white text-slate-700 border border-slate-300 hover:bg-slate-50 active:bg-slate-100"}
          ${size === "sm" ? "text-xs px-2 py-1" : size === "lg" ? "text-lg px-6 py-3" : "text-sm"}
          ${className}
        `,
        children: isCalculating ? /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(LoaderCircle, { className: "w-4 h-4 animate-spin" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Calculando..." })
        ] }) : /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Calculator, { className: "w-4 h-4" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Calcular Índice" })
        ] })
      }
    ),
    error && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 text-xs text-red-600 bg-red-50 p-2 rounded", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(CircleAlert, { className: "w-4 h-4" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: error })
    ] }),
    success && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 text-xs text-green-600 bg-green-50 p-2 rounded", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(CircleCheckBig, { className: "w-4 h-4" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Índice calculado correctamente" })
    ] })
  ] });
};

const {useState: useState$1} = await importShared('react');
const SOIL_TYPES = [
  { value: "clay", label: "Arcilloso", description: "Retiene más carbono" },
  { value: "loam", label: "Franco", description: "Equilibrado" },
  { value: "sandy", label: "Arenoso", description: "Menor retención" },
  { value: "organic", label: "Orgánico", description: "Alta capacidad" }
];
const TILLAGE_TYPES = [
  { value: "conventional", label: "Convencional", factor: 0.7 },
  { value: "reduced", label: "Reducido", factor: 0.85 },
  { value: "no-till", label: "Siembra Directa", factor: 1 }
];
const CarbonInputsWidget = ({
  entityId: propEntityId,
  onSave,
  compact = false
}) => {
  const { selectedEntityId } = useVegetationContext();
  const effectiveEntityId = propEntityId || selectedEntityId;
  const [config, setConfig] = useState$1({
    strawRemoved: false,
    soilType: "loam",
    tillageType: "conventional"
  });
  const [isSaving, setIsSaving] = useState$1(false);
  const [saved, setSaved] = useState$1(false);
  const handleSave = async () => {
    if (!effectiveEntityId) return;
    setIsSaving(true);
    try {
      console.log("Saving carbon config:", config);
      setSaved(true);
      setTimeout(() => setSaved(false), 2e3);
      onSave?.(config);
    } catch (err) {
      console.error("Failed to save carbon config:", err);
    } finally {
      setIsSaving(false);
    }
  };
  if (!effectiveEntityId) {
    return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "p-4 text-center text-slate-500 text-sm", children: "Selecciona una parcela para configurar" });
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `bg-white rounded-lg border border-slate-200 ${compact ? "p-3" : "p-4"}`, children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: `font-semibold text-slate-800 ${compact ? "text-sm mb-2" : "text-base mb-4"}`, children: "🌱 Configuración de Carbono" }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "flex items-center justify-between cursor-pointer", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-sm text-slate-700", children: "¿Se retira la paja?" }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "input",
            {
              type: "checkbox",
              checked: config.strawRemoved,
              onChange: (e) => setConfig({ ...config, strawRemoved: e.target.checked }),
              className: "sr-only"
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `w-10 h-5 rounded-full transition-colors ${config.strawRemoved ? "bg-orange-500" : "bg-green-500"}`, children: /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `absolute top-0.5 left-0.5 w-4 h-4 bg-white rounded-full shadow transition-transform ${config.strawRemoved ? "translate-x-5" : ""}` }) })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-500 mt-1", children: config.strawRemoved ? "⚠️ Menor secuestro de carbono" : "✓ La paja se incorpora al suelo" })
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-sm text-slate-700 mb-2", children: "Tipo de Suelo" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: `grid ${compact ? "grid-cols-2" : "grid-cols-4"} gap-2`, children: SOIL_TYPES.map((soil) => /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          onClick: () => setConfig({ ...config, soilType: soil.value }),
          className: `px-3 py-2 rounded-lg text-xs font-medium transition-all ${config.soilType === soil.value ? "bg-emerald-100 text-emerald-800 border-2 border-emerald-500" : "bg-slate-50 text-slate-600 border border-slate-200 hover:bg-slate-100"}`,
          children: soil.label
        },
        soil.value
      )) })
    ] }),
    !compact && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-sm text-slate-700 mb-2", children: "Sistema de Laboreo" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "select",
        {
          value: config.tillageType,
          onChange: (e) => setConfig({ ...config, tillageType: e.target.value }),
          className: "w-full px-3 py-2 border border-slate-200 rounded-lg text-sm bg-white",
          children: TILLAGE_TYPES.map((tillage) => /* @__PURE__ */ jsxRuntimeExports.jsxs("option", { value: tillage.value, children: [
            tillage.label,
            " (×",
            tillage.factor,
            ")"
          ] }, tillage.value))
        }
      )
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      "button",
      {
        onClick: handleSave,
        disabled: isSaving,
        className: `w-full py-2 rounded-lg font-medium text-sm transition-all ${saved ? "bg-green-500 text-white" : isSaving ? "bg-slate-300 text-slate-500 cursor-wait" : "bg-emerald-600 text-white hover:bg-emerald-700"}`,
        children: saved ? "✓ Guardado" : isSaving ? "Guardando..." : "Guardar Configuración"
      }
    )
  ] });
};

const DateRangePicker = ({
  dateRange,
  onChange,
  presets = true
}) => {
  const formatDate = (date) => {
    if (!date) return "";
    return date.toISOString().split("T")[0];
  };
  const handleStartChange = (e) => {
    const newDate = e.target.value ? new Date(e.target.value) : null;
    onChange({ ...dateRange, startDate: newDate });
  };
  const handleEndChange = (e) => {
    const newDate = e.target.value ? new Date(e.target.value) : null;
    onChange({ ...dateRange, endDate: newDate });
  };
  const setPreset = (days) => {
    const end = /* @__PURE__ */ new Date();
    const start = new Date(Date.now() - days * 24 * 60 * 60 * 1e3);
    onChange({ startDate: start, endDate: end });
  };
  const setYearPreset = (year) => {
    const start = new Date(year, 0, 1);
    const end = new Date(year, 11, 31);
    onChange({ startDate: start, endDate: end });
  };
  const currentYear = (/* @__PURE__ */ new Date()).getFullYear();
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-3", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-2 gap-2", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs text-slate-500 mb-1", children: "Desde" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "input",
          {
            type: "date",
            value: formatDate(dateRange.startDate),
            onChange: handleStartChange,
            className: "w-full px-2 py-1.5 text-sm border border-slate-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          }
        )
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs text-slate-500 mb-1", children: "Hasta" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "input",
          {
            type: "date",
            value: formatDate(dateRange.endDate),
            onChange: handleEndChange,
            className: "w-full px-2 py-1.5 text-sm border border-slate-300 rounded-md focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          }
        )
      ] })
    ] }),
    presets && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-wrap gap-1.5", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          type: "button",
          onClick: () => setPreset(30),
          className: "px-2 py-1 text-xs bg-slate-100 hover:bg-slate-200 rounded-md transition-colors",
          children: "30 días"
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          type: "button",
          onClick: () => setPreset(90),
          className: "px-2 py-1 text-xs bg-slate-100 hover:bg-slate-200 rounded-md transition-colors",
          children: "3 meses"
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          type: "button",
          onClick: () => setPreset(365),
          className: "px-2 py-1 text-xs bg-slate-100 hover:bg-slate-200 rounded-md transition-colors",
          children: "12 meses"
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          type: "button",
          onClick: () => setYearPreset(currentYear),
          className: "px-2 py-1 text-xs bg-blue-100 hover:bg-blue-200 text-blue-700 rounded-md transition-colors",
          children: currentYear
        }
      ),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          type: "button",
          onClick: () => setYearPreset(currentYear - 1),
          className: "px-2 py-1 text-xs bg-slate-100 hover:bg-slate-200 rounded-md transition-colors",
          children: currentYear - 1
        }
      )
    ] }),
    dateRange.startDate && dateRange.endDate && /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-xs text-slate-500", children: [
      Math.ceil((dateRange.endDate.getTime() - dateRange.startDate.getTime()) / (1e3 * 60 * 60 * 24)),
      " días seleccionados"
    ] })
  ] });
};

const {useState,useEffect} = await importShared('react');
const VegetationConfig = ({ mode = "panel" }) => {
  const {
    selectedEntityId,
    selectedIndex,
    setSelectedIndex,
    dateRange,
    setDateRange
  } = useVegetationContext();
  const { config, saveConfig } = useVegetationConfig();
  const api = useVegetationApi();
  const [showCarbonConfig, setShowCarbonConfig] = useState(false);
  const [formula, setFormula] = useState("");
  const [recentJobs, setRecentJobs] = useState([]);
  useEffect(() => {
    api.listJobs("completed", 5, 0).then((response) => {
      if (response && response.jobs) {
        setRecentJobs(response.jobs);
      }
    }).catch(console.error);
  }, []);
  const handleModeChange = (indexType) => {
    setSelectedIndex(indexType);
  };
  if (mode === "panel") {
    return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex flex-col gap-4 p-4 h-full overflow-y-auto", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("section", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-sm font-semibold text-slate-700 mb-2", children: "Índice & Cálculo" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          IndexPillSelector,
          {
            selectedIndex: selectedIndex || "NDVI",
            onIndexChange: setSelectedIndex,
            showCustom: true,
            className: "mb-4"
          }
        ),
        selectedIndex === "CUSTOM" && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-4 p-3 bg-purple-50 rounded-md border border-purple-100", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "block text-xs font-medium text-purple-800 mb-1", children: "Fórmula Personalizada" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "textarea",
            {
              value: formula,
              onChange: (e) => setFormula(e.target.value),
              placeholder: "Ej: (B08 - B04) / (B08 + B04)",
              className: "w-full text-xs border-purple-200 rounded p-2 h-20 focus:ring-purple-500 focus:border-purple-500 font-mono"
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex flex-wrap gap-1 mt-2", children: ["B02", "B03", "B04", "B08", "B11", "B12"].map((b) => /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-[10px] px-1.5 py-0.5 bg-white border border-purple-200 rounded text-purple-600 font-mono cursor-pointer hover:bg-purple-100", onClick: () => setFormula((prev) => prev + b), children: b }, b)) })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("section", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-sm font-semibold text-slate-700 mb-2", children: "Periodo de Análisis" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          DateRangePicker,
          {
            dateRange,
            onChange: setDateRange
          }
        )
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("section", { children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex gap-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          CalculationButton,
          {
            formula: selectedIndex === "CUSTOM" ? formula : void 0,
            startDate: dateRange.startDate?.toISOString().split("T")[0],
            endDate: dateRange.endDate?.toISOString().split("T")[0],
            entityId: selectedEntityId || void 0
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            onClick: async () => {
              if (!selectedEntityId) {
                alert("Seleccione una zona en el mapa primero.");
                return;
              }
              const name = prompt("Nombre para la Nueva Zona de Gestión:");
              if (name) {
                try {
                  const { saveManagementZone } = useVegetationApi();
                  const geom = window.__nekazariContext?.selectedGeometry || null;
                  await saveManagementZone(name, geom, selectedEntityId);
                  alert("Zona guardada correctamente.");
                } catch (e) {
                  console.error(e);
                  alert("Error al guardar zona.");
                }
              }
            },
            className: "flex-1 px-4 py-2 bg-white border border-slate-300 rounded-lg text-sm font-medium text-slate-700 hover:bg-slate-50 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500",
            children: "💾 Guardar Zona"
          }
        )
      ] }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "border-t border-slate-200 my-2" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("section", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between mb-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-sm font-semibold text-slate-700", children: "Opciones Avanzadas" }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "button",
            {
              onClick: () => setShowCarbonConfig(!showCarbonConfig),
              className: "text-xs text-blue-600 hover:text-blue-800",
              children: showCarbonConfig ? "Ocultar" : "Mostrar"
            }
          )
        ] }),
        showCarbonConfig && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-4", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            CarbonInputsWidget,
            {
              entityId: selectedEntityId || void 0,
              compact: true,
              onSave: (cfg) => saveConfig({ ...config, ...cfg })
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "pt-2 border-t border-slate-100", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("h4", { className: "text-xs font-medium text-slate-700 mb-2", children: "Credenciales Copernicus" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "input",
                {
                  type: "text",
                  placeholder: "Client ID (Opcional)",
                  className: "block w-full text-xs border-slate-300 rounded-md shadow-sm focus:border-blue-500 focus:ring-blue-500",
                  value: config.copernicus_client_id || "",
                  onChange: (e) => saveConfig({ ...config, copernicus_client_id: e.target.value })
                }
              ),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "input",
                {
                  type: "password",
                  placeholder: "Client Secret (Opcional)",
                  className: "block w-full text-xs border-slate-300 rounded-md shadow-sm focus:border-blue-500 focus:ring-blue-500",
                  onChange: (e) => saveConfig({ ...config, copernicus_client_secret: e.target.value })
                }
              ),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-[10px] text-slate-400", children: "Dejar en blanco para usar credenciales de plataforma." })
            ] })
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "border-t border-slate-200 my-2" }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("section", { children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "text-sm font-semibold text-slate-700 mb-2", children: "Actividad Reciente" }),
        recentJobs && recentJobs.length > 0 ? /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-2", children: recentJobs.map((job) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "text-xs flex justify-between items-center p-2 bg-slate-50 rounded border border-slate-100", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "font-medium text-slate-800", children: [
              "Descarga ",
              job.status === "completed" ? "✅" : job.status === "failed" ? "❌" : "⏳"
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-slate-500", children: new Date(job.created_at).toLocaleDateString() })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-right", children: job.status === "processing" && /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-blue-500", children: [
            job.progress_percentage,
            "%"
          ] }) })
        ] }, job.id)) }) : /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-slate-400 italic", children: "No hay actividad reciente." })
      ] })
    ] });
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-6 max-w-4xl mx-auto", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("h1", { className: "text-2xl font-bold text-slate-900 mb-6", children: "Configuración Avanzada" }),
    /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "grid grid-cols-1 md:grid-cols-2 gap-6", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white p-6 rounded-xl shadow-sm border border-slate-200", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-lg font-semibold mb-4", children: "Análisis de Vegetación" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          ModeSelector,
          {
            currentIndex: selectedIndex || "NDVI",
            onChange: handleModeChange
          }
        )
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white p-6 rounded-xl shadow-sm border border-slate-200", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-lg font-semibold mb-4", children: "Cálculo de Carbono (LUE)" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          CarbonInputsWidget,
          {
            entityId: selectedEntityId || void 0,
            onSave: (cfg) => saveConfig({ ...config, ...cfg })
          }
        )
      ] })
    ] })
  ] });
};

export { LoaderCircle as L, VegetationConfig as V };
