import { importShared } from './__federation_fn_import-Bs2X4leW.js';
import { j as jsxRuntimeExports } from './jsx-runtime-CsM3lTE3.js';

const {createContext,useContext,useState,useCallback,useEffect} = await importShared('react');

const VegetationContext = createContext(void 0);
const VegetationProvider = ({ children }) => {
  const [selectedEntityId, setSelectedEntityId] = useState(null);
  const [selectedSceneId, setSelectedSceneId] = useState(null);
  const [selectedIndex, setSelectedIndex] = useState(null);
  const [selectedDate, setSelectedDate] = useState(null);
  const [dateRange, setDateRange] = useState({
    startDate: new Date(Date.now() - 90 * 24 * 60 * 60 * 1e3),
    // 90 days ago
    endDate: /* @__PURE__ */ new Date()
  });
  const [selectedGeometry, setSelectedGeometry] = useState(null);
  useEffect(() => {
    const handleEntitySelected = (event) => {
      console.log("[VegetationContext] Received entity selection:", event.detail);
      if (event.detail && event.detail.entityId) {
        setSelectedEntityId(event.detail.entityId);
        setSelectedSceneId(null);
        if (event.detail.geometry) {
          setSelectedGeometry(event.detail.geometry);
        } else {
          setSelectedGeometry(null);
        }
        if (!selectedIndex) setSelectedIndex("NDVI");
      } else {
        setSelectedGeometry(null);
      }
    };
    window.addEventListener("nekazari:entity-selected", handleEntitySelected);
    const globalContext = window.__nekazariContext;
    if (globalContext && globalContext.selectedEntityId) {
      console.log("[VegetationContext] Initializing from global context:", globalContext.selectedEntityId);
      setSelectedEntityId(globalContext.selectedEntityId);
      if (globalContext.selectedGeometry) {
        setSelectedGeometry(globalContext.selectedGeometry);
      }
    }
    return () => {
      window.removeEventListener("nekazari:entity-selected", handleEntitySelected);
    };
  }, []);
  const resetContext = useCallback(() => {
    setSelectedEntityId(null);
    setSelectedSceneId(null);
    setSelectedIndex(null);
    setSelectedDate(null);
    setSelectedGeometry(null);
    setDateRange({
      startDate: new Date(Date.now() - 90 * 24 * 60 * 60 * 1e3),
      endDate: /* @__PURE__ */ new Date()
    });
  }, []);
  return /* @__PURE__ */ jsxRuntimeExports.jsx(
    VegetationContext.Provider,
    {
      value: {
        selectedEntityId,
        selectedSceneId,
        selectedIndex,
        selectedDate,
        dateRange,
        selectedGeometry,
        setSelectedEntityId,
        setSelectedSceneId,
        setSelectedIndex,
        setSelectedDate,
        setDateRange,
        resetContext
      },
      children
    }
  );
};
const useVegetationContext = () => {
  const context = useContext(VegetationContext);
  if (context === void 0) {
    throw new Error("useVegetationContext must be used within a VegetationProvider");
  }
  return context;
};

export { VegetationProvider as V, useVegetationContext as u };
