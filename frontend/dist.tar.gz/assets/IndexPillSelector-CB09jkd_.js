import { importShared } from './__federation_fn_import-Bs2X4leW.js';
import { j as jsxRuntimeExports } from './jsx-runtime-CsM3lTE3.js';
import { c as createLucideIcon } from './createLucideIcon-e3PcgQAe.js';

/**
 * @license lucide-react v0.424.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const Beaker = createLucideIcon("Beaker", [
  ["path", { d: "M4.5 3h15", key: "c7n0jr" }],
  ["path", { d: "M6 3v16a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V3", key: "m1uhx7" }],
  ["path", { d: "M6 14h12", key: "4cwo0f" }]
]);

/**
 * @license lucide-react v0.424.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const Droplet = createLucideIcon("Droplet", [
  [
    "path",
    {
      d: "M12 22a7 7 0 0 0 7-7c0-2-1-3.9-3-5.5s-3.5-4-4-6.5c-.5 2.5-2 4.9-4 6.5C6 11.1 5 13 5 15a7 7 0 0 0 7 7z",
      key: "c7niix"
    }
  ]
]);

/**
 * @license lucide-react v0.424.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const Info = createLucideIcon("Info", [
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
  ["path", { d: "M12 16v-4", key: "1dtifu" }],
  ["path", { d: "M12 8h.01", key: "e9boi3" }]
]);

/**
 * @license lucide-react v0.424.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const Leaf = createLucideIcon("Leaf", [
  [
    "path",
    {
      d: "M11 20A7 7 0 0 1 9.8 6.1C15.5 5 17 4.48 19 2c1 2 2 4.18 2 8 0 5.5-4.78 10-10 10Z",
      key: "nnexq3"
    }
  ],
  ["path", { d: "M2 21c0-3 1.85-5.36 5.08-6C9.5 14.52 12 13 13 12", key: "mt58a7" }]
]);

/**
 * @license lucide-react v0.424.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const Sun = createLucideIcon("Sun", [
  ["circle", { cx: "12", cy: "12", r: "4", key: "4exip2" }],
  ["path", { d: "M12 2v2", key: "tus03m" }],
  ["path", { d: "M12 20v2", key: "1lh1kg" }],
  ["path", { d: "m4.93 4.93 1.41 1.41", key: "149t6j" }],
  ["path", { d: "m17.66 17.66 1.41 1.41", key: "ptbguv" }],
  ["path", { d: "M2 12h2", key: "1t8f8n" }],
  ["path", { d: "M20 12h2", key: "1q8mjw" }],
  ["path", { d: "m6.34 17.66-1.41 1.41", key: "1m8zz5" }],
  ["path", { d: "m19.07 4.93-1.41 1.41", key: "1shlcs" }]
]);

/**
 * @license lucide-react v0.424.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const Target = createLucideIcon("Target", [
  ["circle", { cx: "12", cy: "12", r: "10", key: "1mglay" }],
  ["circle", { cx: "12", cy: "12", r: "6", key: "1vlfrh" }],
  ["circle", { cx: "12", cy: "12", r: "2", key: "1c9p78" }]
]);

/**
 * @license lucide-react v0.424.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const TriangleAlert = createLucideIcon("TriangleAlert", [
  [
    "path",
    {
      d: "m21.73 18-8-14a2 2 0 0 0-3.48 0l-8 14A2 2 0 0 0 4 21h16a2 2 0 0 0 1.73-3",
      key: "wmoenq"
    }
  ],
  ["path", { d: "M12 9v4", key: "juzpu7" }],
  ["path", { d: "M12 17h.01", key: "p32p05" }]
]);

/**
 * @license lucide-react v0.424.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const X = createLucideIcon("X", [
  ["path", { d: "M18 6 6 18", key: "1bl5f8" }],
  ["path", { d: "m6 6 12 12", key: "d8bk6v" }]
]);

const INDEX_INFO = {
  NDVI: {
    id: "NDVI",
    name: "NDVI",
    fullName: "Índice de Vegetación de Diferencia Normalizada",
    description: "El índice más utilizado para medir el verdor y vigor de la vegetación. Detecta la clorofila activa en las plantas.",
    formula: "(NIR - RED) / (NIR + RED)",
    range: [-1, 1],
    interpretation: {
      veryLow: { range: "< 0", meaning: "Agua, nubes o nieve" },
      low: { range: "0 - 0.2", meaning: "Suelo desnudo, roca o zonas urbanizadas" },
      medium: { range: "0.2 - 0.4", meaning: "Vegetación escasa o estresada" },
      high: { range: "0.4 - 0.6", meaning: "Vegetación moderada, cultivos en crecimiento" },
      veryHigh: { range: "> 0.6", meaning: "Vegetación densa y saludable" }
    },
    bestFor: ["Cultivos extensivos (cereales, maíz)", "Monitoreo general de salud", "Pastos y praderas", "Detección de estrés"],
    limitations: "Puede saturarse en vegetación muy densa (bosques). Sensible a efectos atmosféricos.",
    color: "#22c55e"
  },
  EVI: {
    id: "EVI",
    name: "EVI",
    fullName: "Índice de Vegetación Mejorado",
    description: "Versión mejorada del NDVI que corrige distorsiones atmosféricas y reduce la saturación en zonas de alta biomasa.",
    formula: "2.5 × (NIR - RED) / (NIR + 6×RED - 7.5×BLUE + 1)",
    range: [-1, 1],
    interpretation: {
      veryLow: { range: "< 0", meaning: "Sin vegetación" },
      low: { range: "0 - 0.2", meaning: "Vegetación muy escasa" },
      medium: { range: "0.2 - 0.4", meaning: "Vegetación moderada" },
      high: { range: "0.4 - 0.6", meaning: "Vegetación densa" },
      veryHigh: { range: "> 0.6", meaning: "Vegetación muy densa (bosques)" }
    },
    bestFor: ["Bosques densos", "Zonas tropicales", "Alta biomasa", "Estudios forestales"],
    limitations: "Requiere banda azul (B02). Más complejo de calcular.",
    color: "#16a34a"
  },
  NDWI: {
    id: "NDWI",
    name: "NDWI",
    fullName: "Índice de Agua de Diferencia Normalizada",
    description: "Detecta el contenido de agua en la vegetación y superficies. Útil para monitoreo de riego y estrés hídrico.",
    formula: "(GREEN - NIR) / (GREEN + NIR)",
    range: [-1, 1],
    interpretation: {
      veryLow: { range: "< -0.3", meaning: "Vegetación con déficit hídrico severo" },
      low: { range: "-0.3 - 0", meaning: "Vegetación con estrés hídrico" },
      medium: { range: "0 - 0.2", meaning: "Contenido de agua normal" },
      high: { range: "0.2 - 0.4", meaning: "Alto contenido de agua" },
      veryHigh: { range: "> 0.4", meaning: "Cuerpos de agua o zonas inundadas" }
    },
    bestFor: ["Detección de estrés hídrico", "Gestión de riego", "Monitoreo de sequía", "Detección de inundaciones"],
    limitations: "Puede confundir sombras con agua. Menos sensible en vegetación escasa.",
    color: "#3b82f6"
  },
  SAVI: {
    id: "SAVI",
    name: "SAVI",
    fullName: "Índice de Vegetación Ajustado al Suelo",
    description: "Minimiza la influencia del brillo del suelo en zonas con baja cobertura vegetal. Ideal para cultivos jóvenes.",
    formula: "((NIR - RED) / (NIR + RED + L)) × (1 + L)",
    range: [-1, 1],
    interpretation: {
      veryLow: { range: "< 0", meaning: "Suelo sin vegetación" },
      low: { range: "0 - 0.2", meaning: "Vegetación emergente o muy escasa" },
      medium: { range: "0.2 - 0.4", meaning: "Cobertura vegetal parcial" },
      high: { range: "0.4 - 0.6", meaning: "Buena cobertura vegetal" },
      veryHigh: { range: "> 0.6", meaning: "Cobertura vegetal completa" }
    },
    bestFor: ["Cultivos jóvenes (primeras semanas)", "Zonas áridas o semiáridas", "Viñedos", "Olivares"],
    limitations: "Factor L fijo (0.5) puede no ser óptimo para todas las situaciones.",
    color: "#eab308"
  },
  MSAVI: {
    id: "MSAVI",
    name: "MSAVI",
    fullName: "SAVI Modificado",
    description: "Versión mejorada del SAVI que auto-ajusta el factor de corrección según la densidad de vegetación.",
    formula: "(2×NIR + 1 - √((2×NIR + 1)² - 8×(NIR - RED))) / 2",
    range: [-1, 1],
    interpretation: {
      veryLow: { range: "< 0", meaning: "Sin vegetación significativa" },
      low: { range: "0 - 0.2", meaning: "Vegetación muy escasa" },
      medium: { range: "0.2 - 0.4", meaning: "Vegetación en desarrollo" },
      high: { range: "0.4 - 0.6", meaning: "Vegetación bien establecida" },
      veryHigh: { range: "> 0.6", meaning: "Vegetación densa" }
    },
    bestFor: ["Agricultura de precisión", "Zonas con vegetación heterogénea", "Seguimiento de crecimiento"],
    limitations: "Cálculo más complejo. Comportamiento similar a NDVI en vegetación densa.",
    color: "#f97316"
  },
  GNDVI: {
    id: "GNDVI",
    name: "GNDVI",
    fullName: "NDVI Verde",
    description: "Variante del NDVI usando la banda verde. Más sensible a concentraciones de clorofila.",
    formula: "(NIR - GREEN) / (NIR + GREEN)",
    range: [-1, 1],
    interpretation: {
      veryLow: { range: "< 0", meaning: "Sin vegetación" },
      low: { range: "0 - 0.2", meaning: "Vegetación escasa" },
      medium: { range: "0.2 - 0.4", meaning: "Contenido de clorofila moderado" },
      high: { range: "0.4 - 0.6", meaning: "Alta concentración de clorofila" },
      veryHigh: { range: "> 0.6", meaning: "Muy alta actividad fotosintética" }
    },
    bestFor: ["Estimación de nitrógeno", "Aplicación variable de fertilizantes", "Cultivos de hoja"],
    limitations: "Menos común en literatura. Puede ser más ruidoso que NDVI.",
    color: "#84cc16"
  }
};
const getIndexInfo = (indexType) => {
  return INDEX_INFO[indexType.toUpperCase()];
};

const IndexInfoModal = ({
  indexType,
  isOpen,
  onClose
}) => {
  if (!isOpen) return null;
  const info = getIndexInfo(indexType);
  if (!info) {
    return /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "fixed inset-0 z-50 flex items-center justify-center bg-black/50", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white rounded-xl p-6 max-w-md", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-slate-600", children: "Información no disponible para este índice." }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("button", { onClick: onClose, className: "mt-4 px-4 py-2 bg-slate-200 rounded-lg", children: "Cerrar" })
    ] }) });
  }
  return /* @__PURE__ */ jsxRuntimeExports.jsx(
    "div",
    {
      className: "fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm",
      onClick: (e) => e.target === e.currentTarget && onClose(),
      children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-white rounded-2xl shadow-2xl max-w-2xl w-full mx-4 max-h-[90vh] overflow-hidden animate-in fade-in zoom-in-95 duration-200", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs(
          "div",
          {
            className: "px-6 py-4 border-b border-slate-200 flex items-center justify-between",
            style: { backgroundColor: `${info.color}15` },
            children: [
              /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-3", children: [
                /* @__PURE__ */ jsxRuntimeExports.jsx(
                  "div",
                  {
                    className: "p-2 rounded-lg",
                    style: { backgroundColor: `${info.color}25`, color: info.color },
                    children: /* @__PURE__ */ jsxRuntimeExports.jsx(Leaf, { className: "w-6 h-6" })
                  }
                ),
                /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx("h2", { className: "text-xl font-bold text-slate-900", children: info.name }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-slate-600", children: info.fullName })
                ] })
              ] }),
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "button",
                {
                  onClick: onClose,
                  className: "p-2 hover:bg-slate-100 rounded-lg transition-colors",
                  children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-5 h-5 text-slate-500" })
                }
              )
            ]
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "p-6 overflow-y-auto max-h-[calc(90vh-80px)] space-y-6", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { children: /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-slate-700 leading-relaxed", children: info.description }) }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "bg-slate-50 rounded-lg p-4", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 mb-2", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Beaker, { className: "w-4 h-4 text-slate-500" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-semibold text-slate-800", children: "Fórmula" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("code", { className: "text-sm font-mono bg-white px-3 py-2 rounded border border-slate-200 block", children: info.formula })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 mb-3", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Info, { className: "w-4 h-4 text-slate-500" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-semibold text-slate-800", children: "Interpretación de Valores" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "space-y-2", children: Object.entries(info.interpretation).map(([key, { range, meaning }]) => /* @__PURE__ */ jsxRuntimeExports.jsxs(
              "div",
              {
                className: "flex items-center gap-3 p-2 rounded-lg bg-slate-50",
                children: [
                  /* @__PURE__ */ jsxRuntimeExports.jsx(
                    "div",
                    {
                      className: `w-3 h-3 rounded-full ${key === "veryLow" ? "bg-red-500" : key === "low" ? "bg-orange-400" : key === "medium" ? "bg-yellow-400" : key === "high" ? "bg-lime-500" : "bg-green-500"}`
                    }
                  ),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "font-mono text-xs text-slate-600 w-24", children: range }),
                  /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-sm text-slate-700", children: meaning })
                ]
              },
              key
            )) })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 mb-3", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(Target, { className: "w-4 h-4 text-slate-500" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-semibold text-slate-800", children: "Mejor Para" })
            ] }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex flex-wrap gap-2", children: info.bestFor.map((use, i) => /* @__PURE__ */ jsxRuntimeExports.jsx(
              "span",
              {
                className: "px-3 py-1.5 text-sm rounded-full border",
                style: {
                  backgroundColor: `${info.color}10`,
                  borderColor: `${info.color}30`,
                  color: info.color
                },
                children: use
              },
              i
            )) })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "bg-amber-50 border border-amber-200 rounded-lg p-4", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-start gap-2", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(TriangleAlert, { className: "w-4 h-4 text-amber-600 mt-0.5" }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx("h3", { className: "font-semibold text-amber-800 mb-1", children: "Limitaciones" }),
              /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-sm text-amber-700", children: info.limitations })
            ] })
          ] }) })
        ] })
      ] })
    }
  );
};

const {useState} = await importShared('react');
const INDEX_GROUPS = [
  {
    category: "Salud General",
    icon: /* @__PURE__ */ jsxRuntimeExports.jsx(Leaf, { className: "w-4 h-4" }),
    description: "Índices para monitorización general de vegetación",
    indices: [
      { value: "NDVI", label: "NDVI - Normalized Difference Vegetation Index", shortLabel: "NDVI" },
      { value: "EVI", label: "EVI - Enhanced Vegetation Index", shortLabel: "EVI" }
    ]
  },
  {
    category: "Nutrición/Clorofila",
    icon: /* @__PURE__ */ jsxRuntimeExports.jsx(Droplet, { className: "w-4 h-4" }),
    description: "Índices para análisis de nutrición y clorofila",
    indices: [
      { value: "GNDVI", label: "GNDVI - Green Normalized Difference Vegetation Index", shortLabel: "GNDVI" },
      { value: "NDRE", label: "NDRE - Normalized Difference Red Edge", shortLabel: "NDRE" }
    ]
  },
  {
    category: "Suelo/Agua",
    icon: /* @__PURE__ */ jsxRuntimeExports.jsx(Sun, { className: "w-4 h-4" }),
    description: "Índices para etapas tempranas y análisis de suelo",
    indices: [
      { value: "SAVI", label: "SAVI - Soil-Adjusted Vegetation Index", shortLabel: "SAVI" }
    ]
  }
];
const IndexPillSelector = ({
  selectedIndex,
  onIndexChange,
  showCustom = false,
  className = ""
}) => {
  const [infoModalIndex, setInfoModalIndex] = useState(null);
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: `space-y-4 ${className}`, children: [
    INDEX_GROUPS.map((group) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 mb-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "text-gray-500", children: group.icon }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("h4", { className: "text-sm font-semibold text-gray-700", children: group.category })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-gray-500 mb-2", children: group.description }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex flex-wrap gap-2", children: group.indices.map((index) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            onClick: () => onIndexChange(index.value),
            className: `
                    px-3 py-1.5 rounded-full text-sm font-medium transition-all
                    ${selectedIndex === index.value ? "bg-green-600 text-white shadow-md" : "bg-gray-100 text-gray-700 hover:bg-gray-200"}
                  `,
            title: index.label,
            children: index.shortLabel
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            onClick: (e) => {
              e.stopPropagation();
              setInfoModalIndex(index.value);
            },
            className: "p-1 text-gray-400 hover:text-blue-600 hover:bg-blue-50 rounded-full transition-colors",
            title: "Ver información del índice",
            children: /* @__PURE__ */ jsxRuntimeExports.jsx(Info, { className: "w-3.5 h-3.5" })
          }
        )
      ] }, index.value)) })
    ] }, group.category)),
    showCustom && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center gap-2 mb-2", children: /* @__PURE__ */ jsxRuntimeExports.jsx("h4", { className: "text-sm font-semibold text-gray-700", children: "Personalizado" }) }),
      /* @__PURE__ */ jsxRuntimeExports.jsx(
        "button",
        {
          onClick: () => onIndexChange("CUSTOM"),
          className: `
              px-3 py-1.5 rounded-full text-sm font-medium transition-all
              ${selectedIndex === "CUSTOM" ? "bg-purple-600 text-white shadow-md" : "bg-gray-100 text-gray-700 hover:bg-gray-200"}
            `,
          children: "CUSTOM"
        }
      )
    ] }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      IndexInfoModal,
      {
        indexType: infoModalIndex || "",
        isOpen: !!infoModalIndex,
        onClose: () => setInfoModalIndex(null)
      }
    )
  ] });
};

export { IndexPillSelector as I, Leaf as L, X, getIndexInfo as g };
