import { T as TimelineWidget } from './TimelineWidget-LbyuIKEq.js';



export { TimelineWidget, TimelineWidget as default };
