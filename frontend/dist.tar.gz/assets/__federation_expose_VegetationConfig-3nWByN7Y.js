import { V as VegetationConfig } from './VegetationConfig-CT-kLWw1.js';



export { VegetationConfig, VegetationConfig as default };
