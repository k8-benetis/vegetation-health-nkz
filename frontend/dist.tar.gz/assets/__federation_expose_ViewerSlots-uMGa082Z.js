import { T as TimelineWidget } from './TimelineWidget-LbyuIKEq.js';
import { V as VegetationConfig } from './VegetationConfig-CT-kLWw1.js';
import { V as VegetationAnalytics } from './VegetationAnalytics-B80CTd5T.js';
import VegetationLayerControl from './__federation_expose_VegetationLayerControl-Dpj2X4pp.js';
import { VegetationLayer } from './__federation_expose_VegetationLayer-df2wAQT_.js';
import { V as VegetationProvider } from './vegetationContext-DfeO2cmt.js';

const MODULE_ID = "vegetation-prime";
const vegetationPrimeSlots = {
  "map-layer": [
    {
      id: "vegetation-prime-cesium-layer",
      moduleId: MODULE_ID,
      component: "VegetationLayer",
      priority: 10,
      localComponent: VegetationLayer
    }
  ],
  "layer-toggle": [
    {
      id: "vegetation-prime-layer-control",
      moduleId: MODULE_ID,
      component: "VegetationLayerControl",
      priority: 10,
      localComponent: VegetationLayerControl,
      defaultProps: { visible: true },
      showWhen: { entityType: ["AgriParcel"] }
    }
  ],
  "context-panel": [
    {
      id: "vegetation-prime-config",
      moduleId: MODULE_ID,
      component: "VegetationConfig",
      priority: 20,
      localComponent: VegetationConfig,
      defaultProps: { mode: "panel" },
      showWhen: { entityType: ["AgriParcel"] }
    },
    {
      id: "vegetation-prime-analytics",
      moduleId: MODULE_ID,
      component: "VegetationAnalytics",
      priority: 30,
      localComponent: VegetationAnalytics,
      showWhen: { entityType: ["AgriParcel"] }
    }
  ],
  "bottom-panel": [
    {
      id: "vegetation-prime-timeline",
      moduleId: MODULE_ID,
      component: "TimelineWidget",
      priority: 10,
      localComponent: TimelineWidget
    }
  ],
  "entity-tree": [],
  // Host's SlotRenderer wraps all widgets with this provider
  moduleProvider: VegetationProvider
};
const viewerSlots = vegetationPrimeSlots;

export { vegetationPrimeSlots as default, vegetationPrimeSlots, viewerSlots };
