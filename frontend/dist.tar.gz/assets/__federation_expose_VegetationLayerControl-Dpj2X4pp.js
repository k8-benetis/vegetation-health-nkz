import { importShared } from './__federation_fn_import-Bs2X4leW.js';
import { j as jsxRuntimeExports } from './jsx-runtime-CsM3lTE3.js';
import { u as useUIKit, a as useViewer } from './useUIKit-CUK97iho.js';
import { u as useVegetationContext } from './vegetationContext-DfeO2cmt.js';
import { c as createLucideIcon, u as useVegetationApi } from './createLucideIcon-e3PcgQAe.js';
import { X, I as IndexPillSelector } from './IndexPillSelector-CB09jkd_.js';
import { C as Calendar } from './calendar-BM24y3pm.js';
import { L as Layers } from './layers-DK5sOaWK.js';

/**
 * @license lucide-react v0.424.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */


const Cloud = createLucideIcon("Cloud", [
  ["path", { d: "M17.5 19H9a7 7 0 1 1 6.71-9h1.79a4.5 4.5 0 1 1 0 9Z", key: "p7xjir" }]
]);

const {useState: useState$1,useEffect: useEffect$1,useCallback} = await importShared('react');
function useVegetationScenes(options = {}) {
  const {
    entityId,
    startDate,
    endDate,
    limit = 50,
    autoRefresh = false
  } = options;
  const api = useVegetationApi();
  const [scenes, setScenes] = useState$1([]);
  const [loading, setLoading] = useState$1(true);
  const [error, setError] = useState$1(null);
  const loadScenes = useCallback(async () => {
    try {
      setLoading(true);
      setError(null);
      const data = await api.listScenes(entityId || void 0, startDate, endDate, limit);
      setScenes(data.scenes || []);
    } catch (err) {
      console.error("[useVegetationScenes] Error loading scenes:", err);
      setError(err instanceof Error ? err.message : "Failed to load scenes");
      setScenes([]);
    } finally {
      setLoading(false);
    }
  }, [api, entityId, startDate, endDate, limit]);
  useEffect$1(() => {
    loadScenes();
  }, [loadScenes]);
  useEffect$1(() => {
    if (!autoRefresh) return;
    const interval = setInterval(() => {
      loadScenes();
    }, 3e4);
    return () => clearInterval(interval);
  }, [autoRefresh, loadScenes]);
  return {
    scenes,
    loading,
    error,
    refresh: loadScenes
  };
}

const {useMemo} = await importShared('react');

function getIndexColor(value, _indexType) {
  const normalized = Math.max(0, Math.min(1, (value + 1) / 2));
  if (normalized < 0.2) return `rgb(${255}, ${Math.floor(255 * (normalized / 0.2))}, 0)`;
  if (normalized < 0.5) {
    const t2 = (normalized - 0.2) / 0.3;
    return `rgb(255, ${Math.floor(255 * (1 - t2 * 0.5))}, 0)`;
  }
  if (normalized < 0.7) {
    const t2 = (normalized - 0.5) / 0.2;
    return `rgb(${Math.floor(255 * (1 - t2))}, 255, ${Math.floor(100 * t2)})`;
  }
  const t = (normalized - 0.7) / 0.3;
  return `rgb(0, ${Math.floor(200 + 55 * t)}, ${Math.floor(100 * t)})`;
}
function getIndexLegend(indexType, dynamic = false, dataMin, dataMax) {
  const baseStops = [
    { value: -1, color: "#8B0000", label: "No Vegetation" },
    { value: 0, color: "#FFD700", label: "Low" },
    { value: 0.3, color: "#FFA500", label: "Moderate" },
    { value: 0.5, color: "#ADFF2F", label: "Good" },
    { value: 0.7, color: "#32CD32", label: "High" },
    { value: 1, color: "#006400", label: "Very High" }
  ];
  const descriptions = {
    NDVI: "Normalized Difference Vegetation Index - Measures vegetation health and density",
    EVI: "Enhanced Vegetation Index - Reduces atmospheric and soil effects",
    SAVI: "Soil-Adjusted Vegetation Index - Best for areas with exposed soil",
    GNDVI: "Green Normalized Difference Vegetation Index - Sensitive to chlorophyll content",
    NDRE: "Normalized Difference Red Edge - Sensitive to crop stress and nitrogen",
    NDMI: "Normalized Difference Moisture Index - Measures vegetation water content",
    SAMI: "Sentinel-1 Soil Moisture Activity - Radar-based soil moisture proxy",
    VRA_ZONES: "Variable Rate Application Zones - AI-clustered management zones",
    CUSTOM: "Custom Index - User-defined formula"
  };
  const effectiveMin = dynamic && dataMin !== void 0 ? dataMin : -1;
  const effectiveMax = dynamic && dataMax !== void 0 ? dataMax : 1;
  const dynamicStops = dynamic ? baseStops.map((stop) => ({
    ...stop,
    value: effectiveMin + (stop.value + 1) * ((effectiveMax - effectiveMin) / 2)
  })) : baseStops;
  return {
    min: effectiveMin,
    max: effectiveMax,
    stops: dynamicStops,
    description: descriptions[indexType],
    dynamic,
    dataMin: dynamic ? dataMin : void 0,
    dataMax: dynamic ? dataMax : void 0
  };
}
function useIndexLegend(indexType, dynamic = false, dataMin, dataMax) {
  const legend = useMemo(
    () => getIndexLegend(indexType, dynamic, dataMin, dataMax),
    [indexType, dynamic, dataMin, dataMax]
  );
  const getColor = useMemo(
    () => (value) => {
      if (dynamic && dataMin !== void 0 && dataMax !== void 0) {
        const normalized = (value - dataMin) / (dataMax - dataMin || 1);
        const clamped = Math.max(0, Math.min(1, normalized));
        return getIndexColor(clamped * 2 - 1);
      }
      return getIndexColor(value);
    },
    [indexType, dynamic, dataMin, dataMax]
  );
  return { legend, getColor };
}

const ColorScaleLegend = ({
  indexType,
  position = "top-right",
  onClose,
  className = "",
  dynamic = false,
  dataMin,
  dataMax,
  onDynamicToggle
}) => {
  const { legend } = useIndexLegend(indexType, dynamic, dataMin, dataMax);
  const positionClasses = {
    "top-right": "top-4 right-4",
    "top-left": "top-4 left-4",
    "bottom-right": "bottom-4 right-4",
    "bottom-left": "bottom-4 left-4"
  };
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(
    "div",
    {
      className: `
        absolute ${positionClasses[position]} 
        bg-white rounded-lg shadow-lg border border-gray-200 p-4 z-50
        min-w-[200px] ${className}
      `,
      children: [
        onClose && /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            onClick: onClose,
            className: "absolute top-2 right-2 text-gray-400 hover:text-gray-600 transition-colors",
            children: /* @__PURE__ */ jsxRuntimeExports.jsx(X, { className: "w-4 h-4" })
          }
        ),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "mb-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between mb-1", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("h4", { className: "text-sm font-semibold text-gray-900", children: indexType }),
            onDynamicToggle && /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "flex items-center gap-1 text-xs cursor-pointer", children: [
              /* @__PURE__ */ jsxRuntimeExports.jsx(
                "input",
                {
                  type: "checkbox",
                  checked: dynamic,
                  onChange: (e) => onDynamicToggle(e.target.checked),
                  className: "rounded border-gray-300 text-green-600 focus:ring-green-500"
                }
              ),
              /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-gray-600", children: "Auto-stretch" })
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("p", { className: "text-xs text-gray-500", children: legend.description }),
          dynamic && dataMin !== void 0 && dataMax !== void 0 && /* @__PURE__ */ jsxRuntimeExports.jsxs("p", { className: "text-xs text-blue-600 mt-1", children: [
            "Rango dinámico: ",
            dataMin.toFixed(3),
            " - ",
            dataMax.toFixed(3)
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "relative h-6 w-full rounded overflow-hidden mb-2 border border-gray-300", children: /* @__PURE__ */ jsxRuntimeExports.jsx(
          "div",
          {
            className: "absolute inset-0",
            style: {
              background: `linear-gradient(to right, 
              ${legend.stops[0].color} 0%, 
              ${legend.stops[1].color} 20%, 
              ${legend.stops[2].color} 40%, 
              ${legend.stops[3].color} 60%, 
              ${legend.stops[4].color} 80%, 
              ${legend.stops[5].color} 100%)`
            }
          }
        ) }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex justify-between text-xs text-gray-600", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: legend.min.toFixed(1) }),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: legend.max.toFixed(1) })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "mt-2 space-y-1", children: legend.stops.slice(1, -1).map((stop, idx) => /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-2 text-xs", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "div",
            {
              className: "w-4 h-4 rounded border border-gray-300",
              style: { backgroundColor: stop.color }
            }
          ),
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-gray-600", children: stop.label }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { className: "text-gray-400 ml-auto", children: [
            "(",
            stop.value.toFixed(1),
            ")"
          ] })
        ] }, idx)) })
      ]
    }
  );
};

const DateSelector = ({ selectedDate, scenes, onSelect }) => {
  return /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "relative", children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none", children: /* @__PURE__ */ jsxRuntimeExports.jsx(Calendar, { className: "h-4 w-4 text-slate-400" }) }),
    /* @__PURE__ */ jsxRuntimeExports.jsx(
      "select",
      {
        value: selectedDate,
        onChange: (e) => {
          const date = e.target.value;
          const scene = scenes.find((s) => s.sensing_date === date);
          if (scene) {
            onSelect(date, scene.id);
          }
        },
        className: "block w-full pl-10 pr-3 py-2 text-xs border border-slate-200 rounded-lg focus:ring-green-500 focus:border-green-500 bg-slate-50 text-slate-700 appearance-none",
        children: scenes.length === 0 ? /* @__PURE__ */ jsxRuntimeExports.jsx("option", { value: "", children: "Sin imágenes" }) : scenes.map((scene) => /* @__PURE__ */ jsxRuntimeExports.jsxs("option", { value: scene.sensing_date, children: [
          scene.sensing_date,
          " (",
          scene.cloud_coverage?.toFixed(0),
          "% nubes)"
        ] }, scene.id))
      }
    )
  ] });
};

const {useState,useEffect} = await importShared('react');
const VegetationLayerControl = () => {
  const { Card } = useUIKit();
  const { setCurrentDate } = useViewer();
  const {
    selectedIndex,
    selectedDate,
    selectedEntityId,
    selectedSceneId,
    setSelectedIndex,
    setSelectedDate,
    setSelectedSceneId
  } = useVegetationContext();
  const { scenes, loading: scenesLoading } = useVegetationScenes({
    entityId: selectedEntityId || void 0
  });
  const [showCloudMask, setShowCloudMask] = useState(false);
  const [opacity, setOpacity] = useState(100);
  const [showLegend, setShowLegend] = useState(true);
  const currentScene = scenes.find((s) => s.id === selectedSceneId);
  const cloudCoverage = currentScene?.cloud_coverage ?? 0;
  const [legendDynamic, setLegendDynamic] = useState(false);
  useEffect(() => {
    if (selectedDate && setCurrentDate) {
      setCurrentDate(selectedDate);
    }
  }, [selectedDate, setCurrentDate]);
  const handleDateChange = (dateStr, sceneId) => {
    setSelectedDate(new Date(dateStr));
    setSelectedSceneId(sceneId);
  };
  if (!selectedEntityId) {
    return /* @__PURE__ */ jsxRuntimeExports.jsx(Card, { padding: "md", className: "bg-white/90 backdrop-blur-md border border-slate-200/50 rounded-xl w-full", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-center gap-2 py-4 text-slate-500", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsx(Layers, { className: "w-5 h-5" }),
      /* @__PURE__ */ jsxRuntimeExports.jsx("p", { children: "Selecciona una parcela para ver capas" })
    ] }) });
  }
  const selectedDateStr = selectedDate ? selectedDate.toISOString().split("T")[0] : "";
  return /* @__PURE__ */ jsxRuntimeExports.jsxs(jsxRuntimeExports.Fragment, { children: [
    /* @__PURE__ */ jsxRuntimeExports.jsx(Card, { padding: "md", className: "bg-white/90 backdrop-blur-md border border-slate-200/50 rounded-xl w-80 shadow-lg pointer-events-auto", children: /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-4", children: [
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between border-b border-slate-100 pb-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("h3", { className: "font-semibold text-slate-800 flex items-center gap-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx(Layers, { className: "w-4 h-4 text-green-600" }),
          "Capas de Vegetación"
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx("div", { className: "flex items-center gap-1", children: /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs text-slate-500 font-mono", children: selectedEntityId.split(":").pop() }) })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("label", { className: "text-xs font-medium text-slate-600 uppercase tracking-wider", children: "Índice Espectral" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          IndexPillSelector,
          {
            selectedIndex: selectedIndex || "NDVI",
            onIndexChange: (idx) => setSelectedIndex(idx)
          }
        )
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "text-xs font-medium text-slate-600 uppercase tracking-wider flex justify-between", children: [
          "Fecha de Imagen",
          scenesLoading && /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-slate-400", children: "Cargando..." })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          DateSelector,
          {
            selectedDate: selectedDateStr,
            scenes,
            onSelect: handleDateChange
          }
        ),
        currentScene && /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-4 text-xs text-slate-500 mt-1 bg-slate-50 p-1.5 rounded border border-slate-100", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center gap-1", title: "Cobertura de nubes", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx(Cloud, { className: `w-3 h-3 ${cloudCoverage > 20 ? "text-amber-500" : "text-slate-400"}` }),
            /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
              cloudCoverage.toFixed(1),
              "%"
            ] })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { children: [
            "ID: ",
            currentScene.id.substring(0, 8),
            "..."
          ] })
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-1", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex justify-between text-xs text-slate-600", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Opacidad" }),
          /* @__PURE__ */ jsxRuntimeExports.jsxs("span", { children: [
            opacity,
            "%"
          ] })
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "input",
          {
            type: "range",
            min: "0",
            max: "100",
            value: opacity,
            onChange: (e) => setOpacity(parseInt(e.target.value)),
            className: "w-full h-1.5 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-green-600"
          }
        )
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "space-y-2 pt-2 border-t border-slate-100", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "text-sm text-slate-700 flex flex-col", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Máscara de Nubes" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs text-slate-400", children: "Ocultar áreas nubladas" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "input",
            {
              type: "checkbox",
              checked: showCloudMask,
              onChange: (e) => setShowCloudMask(e.target.checked),
              className: "toggle toggle-sm toggle-success"
            }
          )
        ] }),
        /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between mt-2", children: [
          /* @__PURE__ */ jsxRuntimeExports.jsxs("label", { className: "text-sm text-slate-700 flex flex-col", children: [
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { children: "Rango Dinámico" }),
            /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs text-slate-400", children: "Ajustar color a min/max" })
          ] }),
          /* @__PURE__ */ jsxRuntimeExports.jsx(
            "input",
            {
              type: "checkbox",
              checked: legendDynamic,
              onChange: (e) => setLegendDynamic(e.target.checked),
              className: "toggle toggle-sm toggle-success"
            }
          )
        ] })
      ] }),
      /* @__PURE__ */ jsxRuntimeExports.jsxs("div", { className: "flex items-center justify-between pt-2 border-t border-slate-200", children: [
        /* @__PURE__ */ jsxRuntimeExports.jsx("span", { className: "text-xs text-slate-600", children: "Leyenda de colores" }),
        /* @__PURE__ */ jsxRuntimeExports.jsx(
          "button",
          {
            onClick: () => setShowLegend(!showLegend),
            className: "text-xs text-green-600 hover:text-green-700",
            children: showLegend ? "Ocultar" : "Mostrar"
          }
        )
      ] })
    ] }) }),
    showLegend && /* @__PURE__ */ jsxRuntimeExports.jsx(
      ColorScaleLegend,
      {
        indexType: selectedIndex || "NDVI",
        position: "top-right",
        onClose: () => setShowLegend(false),
        dynamic: legendDynamic,
        onDynamicToggle: setLegendDynamic,
        dataMin: void 0,
        dataMax: void 0
      }
    )
  ] });
};

export { VegetationLayerControl as default };
