export { i as default } from './index-c2uneIgs.js';
